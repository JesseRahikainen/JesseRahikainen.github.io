Xturos
======
A simple little game engine I've been working for doing Ludum Dare competitions. Nothing too fancy.

Dependancies:
SDL2 2.0.5
STB