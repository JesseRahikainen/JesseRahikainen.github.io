#ifndef SWEPT_COLLISION_DETECCTION_H
#define SWEPT_COLLISION_DETECCTION_H

#endif // inclusion guard