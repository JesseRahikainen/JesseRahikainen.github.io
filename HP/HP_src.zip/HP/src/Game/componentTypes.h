#ifndef COMPONENT_TYPES_H
#define COMPONENT_TYPES_H

#include "../Math/vector2.h"
#include "../Graphics/color.h"
#include "../collisionDetection.h"
#include "animations.h"

typedef struct {
	Vector2 currPos;
	Vector2 futurePos;
} PosData;

typedef struct {
	Vector2 vel;
	float timeOffGround;
} PhysicsData;

typedef struct {
	int img;
	Color clr; 
	Vector2 scale;
	int8_t depth;
} RenderData;

typedef struct {
	Vector2 halfDim;
} CollisionData;

typedef struct {
	Vector2 offset;
} StaticCollisionOffset;

typedef struct {
	Vector2 lastPos;
	float direction;
	float maxSpeed;
	float turnCheckDist;
	Animation* idleAnim;
	Animation* walkAnim;
} ZombieAIData;

typedef struct {
	EntityID parent;
	EntityID nextSibling;
	EntityID firstChild;
	Vector2 offset;
} AttachableData;

typedef struct {
	Animation* anim;
	float frameTime;
	uint32_t frameIdx;
} AnimatedData;

typedef struct {
	Collider coll;
	EntityID entity;
} ColliderInfo;

typedef struct {
	float yOffset;
} RenderOffset;

typedef struct {
	uint32_t idx;
} ObjectTypeIndex;

typedef struct {
	ECPS ecps;
	ComponentID posComp;
	ComponentID physicsComp;
	ComponentID playerInputComp;
	ComponentID renderComp;
	ComponentID dynamicCollisionComp;
	ComponentID staticCollisionComp;
	ComponentID triggerCollisionComp;
	ComponentID zombieAIComp;
	ComponentID attachableComp;
	ComponentID dragFlagComp;
	ComponentID pushableFlagComp;
	ComponentID canPushFlagComp;
	ComponentID crushableFlagComp;
	ComponentID canCrushFlagComp;
	ComponentID destroyFlagComp;
	ComponentID reloadOnDeathFlagComp;
	ComponentID canRideFlagComp;
	ComponentID canBeRiddenFlagComp;
	ComponentID canKillAnythingComp;
	ComponentID canKillPlayerComp;
	ComponentID endLevelFlagComp;
	ComponentID animatedComp;
	ComponentID renderOffsetComp;
	ComponentID objectTypeIdxComp;
	ComponentID staticCollisionOffsetComp;
	ComponentID doNotRenderInGameFlagComp;
} ECPSSetup;

#endif /* inclusion guard */