#ifndef TEST_JOB_QUEUE_SCREEN_H
#define TEST_JOB_QUEUE_SCREEN_H

#include "../gameState.h"

struct GameState testJobQueueScreenState;

#endif // inclusion guard