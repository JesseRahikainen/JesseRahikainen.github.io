#include "gameScreen.h"

#include <math.h>

#include "../Graphics/graphics.h"
#include "../Graphics/images.h"
#include "../Graphics/spineGfx.h"
#include "../Graphics/camera.h"
#include "../Graphics/debugRendering.h"
#include "../Graphics/imageSheets.h"
#include "../UI/text.h"
#include "../System/entityIDs.h"
#include "../particles.h"

#include "../System/ECPS/entityComponentProcessSystem.h"
#include "../collisionDetection.h"
#include "../Input/input.h"
#include "../Utils/stretchyBuffer.h"
#include "../System/platformLog.h"
#include "../Utils/helpers.h"

#include "resources.h"
#include "objectTypes.h"
#include "componentTypes.h"
#include "level.h"

//**************************************************************************************************

static ECPSSetup gameECPSSetup;

static Process renderProc;
static Process inputProc;
static Process cameraProc;
static Process physicsProc;
static Process collisionProc;
static Process cleanUpProc;
static Process checkReloadProc;
static Process zombieAIProc;
static Process animatedProc;
static Process drawDynamicCollidersProc;
static Process detachEverythingProc;
static Process drawAttachmentsProc;
static Process addToStaticCollisionListProc;
static Process addToTriggerCollisionListProc;

static uint32_t countBitsSet( uint8_t bits )
{
	uint32_t cnt;
	for( cnt = 0; bits; ++cnt ) {
		bits &= bits - 1; // clear the least significant bit set
	}
	return cnt;
}

//typedef void (*PreProcFunc)( void );
//typedef void (*ProcFunc)( const Entity* entity );
//typedef void (*PostProcFunc)( void );

static bool leftDown = false;
static bool rightDown = false;
static bool upDown = false;
static bool downDown = false;
static bool resetPressedDown = false;
static int currLevel = 0;
static int nextLevel = 0;

static void loadLevel( int idx );

static float deltaTime;

static ColliderInfo* sbStaticColliders = NULL;
static ColliderInfo* sbTriggerColliders = NULL;
static ColliderInfo* sbDynamicColliders = NULL;

static void attachEntity( const Entity* parent, const Entity* child )
{
	AttachableData* parentAttach = NULL;
	AttachableData* childAttach = NULL;

	ecps_GetComponentFromEntity( parent, gameECPSSetup.attachableComp, &parentAttach );
	ecps_GetComponentFromEntity( child, gameECPSSetup.attachableComp, &childAttach );

	if( childAttach == NULL ) { llog( LOG_VERBOSE, "Attempting to attach child without attachable component" ); return; }
	if( parentAttach == NULL ) { llog( LOG_VERBOSE, "Attempting to attach to parent without attachable component" ); return; }
	if( childAttach->parent != INVALID_ENTITY ) { llog( LOG_VERBOSE, "Attempting to attach a child that is already attached." ); return; }

	// linked list hook up
	childAttach->parent = parent->id;
	childAttach->nextSibling = parentAttach->firstChild;
	parentAttach->firstChild = child->id;
}

static void detachEntity( const Entity* child )
{
	AttachableData* childAttach = NULL;

	ecps_GetComponentFromEntity( child, gameECPSSetup.attachableComp, &childAttach );

	if( childAttach == NULL ) { llog( LOG_VERBOSE, "Attempting to detach an entity with no attachable component" ); return; }

	Entity parent;
	if( !ecps_GetEntityByID( &(gameECPSSetup.ecps), childAttach->parent, &parent ) ) {
		// just in case the entity got deleted
		childAttach->parent = INVALID_ENTITY;
		llog( LOG_VERBOSE, "Attempting to detach an entity that has no parent" );
		return;
	}

	// unhook from linked list
	AttachableData* parentAttach = NULL;
	ecps_GetComponentFromEntity( &parent, gameECPSSetup.attachableComp, &parentAttach );

	if( parentAttach->firstChild == child->id ) {
		parentAttach->firstChild = childAttach->nextSibling;
	} else {
		// not the first, need to find the the sibling before it
		EntityID id = parentAttach->firstChild;
		AttachableData* prevData = NULL;
		ecps_GetComponentFromEntityByID( &(gameECPSSetup.ecps), parentAttach->firstChild, gameECPSSetup.attachableComp, &prevData );

		while( prevData->nextSibling != child->id ) {
			assert( prevData->nextSibling != INVALID_ENTITY );
			ecps_GetComponentFromEntityByID( &(gameECPSSetup.ecps), prevData->nextSibling, gameECPSSetup.attachableComp, &prevData );
			assert( prevData != NULL );
		}
		prevData->nextSibling = childAttach->nextSibling;
	}

	childAttach->parent = INVALID_ENTITY;
	childAttach->nextSibling = INVALID_ENTITY;
}

static void detachAllChildren( const Entity* entity )
{
	AttachableData* attach = NULL;
	ecps_GetComponentFromEntity( entity, gameECPSSetup.attachableComp, &attach );

	EntityID currID = attach->firstChild;
	attach->firstChild = INVALID_ENTITY;
	while( currID != INVALID_ENTITY ) {
		AttachableData* childAttach = NULL;
		ecps_GetComponentFromEntityByID( &(gameECPSSetup.ecps), currID, gameECPSSetup.attachableComp, &childAttach );
		assert( childAttach != NULL );

		currID = childAttach->nextSibling;
		childAttach->parent = INVALID_ENTITY;
		childAttach->nextSibling = INVALID_ENTITY;
	}
}

static void spawnDeathParticles( Vector2 pos )
{
	// spawn particle effects
	Vector2 smokeGrav = vec2( 0.0f, -1.5f * BASE_SIZE.y );
	Vector2 partDirs[] = {
		{ 0.0f, 1.0f },
		{ 0.0f, -1.0f },
		{ -1.0f, 0.0f },
		{ 1.0f, 0.0f },
		{ 0.707f, 0.707f },
		{ -0.707f, 0.707f },
		{ 0.707f, -0.707f },
		{ -0.707f, -0.707f },
		{ 0.0f, 0.0f }
	};
	for( int i = 0; i < ARRAY_SIZE( partDirs ); ++i ) {
		Vector2 vel;
		vec2_Scale( &( partDirs[i] ), 0.5f * BASE_SIZE.x, &vel );
		particles_Spawn( pos, vel, smokeGrav, 0.0f, 0.75f, 0.5f, smokeImg, 1, 10 );
	}
}

static void genericDestoryObject( const Entity* entity )
{
	EntityID id = entity->id;
	PosData* pos = NULL;
	ecps_GetComponentFromEntityByID( &(gameECPSSetup.ecps), id, gameECPSSetup.posComp, &pos );
	if( pos != NULL ) {
		spawnDeathParticles( pos->futurePos );
	}

	AttachableData* attach = NULL;
	ecps_GetComponentFromEntityByID( &(gameECPSSetup.ecps), id, gameECPSSetup.attachableComp, &attach );
	if( attach != NULL ) {
		Entity e;
		ecps_GetEntityByID( &(gameECPSSetup.ecps), id, &e );
		detachEntity( &e );
		detachAllChildren( &e );

		//ecps_RemoveComponentFromEntityByID( &(gameECPSSetup.ecps), id, gameECPSSetup.attachableComp );
	}
	ecps_AddComponentToEntityByID( &(gameECPSSetup.ecps), id, gameECPSSetup.destroyFlagComp, NULL );
}

static Vector2 camMin;
static Vector2 camMax;
void positionCamera( const Entity* entity )
{
	Vector2 newCamPos;
	// first get the player position
	PosData* pos = NULL;
	ecps_GetComponentFromEntity( entity, gameECPSSetup.posComp, &pos );
	newCamPos = pos->futurePos;

	// center camera on player
	int rwi;
	int rhi;
	gfx_GetRenderSize( &rwi, &rhi );
	float renderWidth = (float)rwi;
	float renderHeight = (float)rhi;
	float halfRenderWidth = renderWidth / 2.0f;
	float halfRenderHeight = renderHeight / 2.0f;

	newCamPos.x = pos->futurePos.x - halfRenderWidth;
	newCamPos.y = pos->futurePos.y - halfRenderHeight;

	newCamPos.x = clamp( camMin.x, camMax.x, newCamPos.x );
	newCamPos.y = clamp( camMin.y, camMax.y, newCamPos.y );

	cam_SetNextState( 0, newCamPos, 1.0f );
}

void collisionRender( const Entity* entity )
{
	PosData* pd = NULL;
	CollisionData* cd = NULL;

	ecps_GetComponentFromEntity( entity, gameECPSSetup.posComp, &pd );
	ecps_GetComponentFromEntity( entity, gameECPSSetup.dynamicCollisionComp, &cd );

	Collider c;
	c.type = CT_AABB;
	c.aabb.center = pd->futurePos;
	c.aabb.halfDim = cd->halfDim;
	
	collision_DebugDrawing( &c, 1, CLR_BLUE );
}

void attachmentRender( const Entity* entity )
{
	PosData* pd = NULL;
	AttachableData* ad = NULL;

	ecps_GetComponentFromEntity( entity, gameECPSSetup.posComp, &pd );
	ecps_GetComponentFromEntity( entity, gameECPSSetup.attachableComp, &ad );

	EntityID currID = ad->firstChild;
	while( currID != INVALID_ENTITY ) {
		Entity child;
		PosData* childPos;
		AttachableData* childAttach;

		ecps_GetEntityByID( &(gameECPSSetup.ecps), currID, &child );
		ecps_GetComponentFromEntity( &child, gameECPSSetup.posComp, &childPos );
		ecps_GetComponentFromEntity( &child, gameECPSSetup.attachableComp, &childAttach );
		assert( childPos != NULL );
		assert( childAttach != NULL );

		debugRenderer_Line( 1, pd->currPos, childPos->currPos, CLR_YELLOW );

		currID = childAttach->nextSibling;
	}
}

static void render( const Entity* entity )
{
	if( ecps_DoesEntityHaveComponent( entity, gameECPSSetup.doNotRenderInGameFlagComp ) ) {
		return;
	}

	PosData* pos = NULL;
	RenderData* rd = NULL;

	ecps_GetComponentFromEntity( entity, gameECPSSetup.posComp, &pos );
	ecps_GetComponentFromEntity( entity, gameECPSSetup.renderComp, &rd );

	Vector2 currPos = pos->currPos;
	Vector2 futurePos = pos->futurePos;

	RenderOffset* offset = NULL;
	if( ecps_GetComponentFromEntity( entity, gameECPSSetup.renderOffsetComp, &offset ) ) {
		currPos.y += offset->yOffset;
		futurePos.y += offset->yOffset;
	}

	AnimatedData* animData = NULL;
	ecps_GetComponentFromEntity( entity, gameECPSSetup.animatedComp, &animData );
	if( animData != NULL ) {
		Vector2 offset = animData->anim->sbFrames[animData->frameIdx].offset;
		offset.x *= sign( rd->scale.x );
		offset.y *= sign( rd->scale.y );
		vec2_Add( &currPos, &offset, &currPos );
		vec2_Add( &futurePos, &offset, &futurePos );
	}

	img_Draw_sv_c( rd->img, 1, currPos, futurePos, rd->scale, rd->scale, rd->clr, rd->clr, rd->depth );

	pos->currPos = pos->futurePos;
}

void playerInput(const Entity* entity)
{
	PhysicsData* pd;

	ecps_GetComponentFromEntity( entity, gameECPSSetup.physicsComp, &pd );

	// jump
	//  the base jump should go up about 1.5 blocks at minimum, 2.5 blocks to maximum
	if( pd->timeOffGround <= 0.1f ) {
		if( upDown ) {
			pd->vel.y = BASE_SIZE.y * ( -125.0f / 32.0f );
		}
	} else {
		if( !upDown && ( pd->vel.y < 0.0f ) ) {
			pd->vel.y = 0.0f;
		}
		if( upDown && ( pd->timeOffGround <= 0.5f ) ) {
			pd->vel.y -= BASE_SIZE.y * ( 125.0f / 32.0f ) * deltaTime;
		}
	}

	float acc;
	float reverseAcc;
	float maxSpeed = BASE_SIZE.x * ( 75.0f / 32.0f );
	if( pd->timeOffGround <= 0.0f ) {
		acc = BASE_SIZE.x * ( 200.0f / 32.0f ) * deltaTime;
		reverseAcc = BASE_SIZE.x * ( 300.0f / 32.0f ) * deltaTime;
	} else {
		acc = BASE_SIZE.x * ( 10.0f / 32.0f ) * deltaTime;
		reverseAcc = BASE_SIZE.x * ( 10.0f / 32.0f ) * deltaTime;
	}
	if( leftDown ) {
		if( pd->vel.x > 0.0f ) {
			pd->vel.x -= reverseAcc;
		} else {
			pd->vel.x -= acc;
		}
	}
	if( rightDown ) {
		if( pd->vel.x < 0.0f ) {
			pd->vel.x += reverseAcc;
		} else {
			pd->vel.x += acc;
		}
	}
	if( fabs( pd->vel.x ) > maxSpeed ) {
		pd->vel.x = sign( pd->vel.x ) * maxSpeed;
	}

	if( ( !( leftDown || rightDown ) ) && ( pd->timeOffGround <= 0.0f ) ) {
		float drag = BASE_SIZE.x * ( 250.0f / 32.0f );
		if( fabsf( pd->vel.x ) <= ( drag * deltaTime ) ) {
			pd->vel.x = 0.0f;
		} else {
			pd->vel.x -= sign( pd->vel.x ) * drag * deltaTime;
		}
	}

	// update animation playing and direction
	RenderData* rd = NULL;
	AnimatedData* ad = NULL;

	ecps_GetComponentFromEntity( entity, gameECPSSetup.renderComp, &rd );
	ecps_GetComponentFromEntity( entity, gameECPSSetup.animatedComp, &ad );
	if( rd && ad ) {
		if( leftDown ) {
			rd->scale.x = -fabsf( rd->scale.x );
		} else if( rightDown ) {
			rd->scale.x = fabsf( rd->scale.x );
		}

		if( pd->timeOffGround > 0.0f ) {
			if( pd->vel.y < 0.0f ) {
				if( ad->anim != &girlJumpUp ) {
					ad->anim = &girlJumpUp;
					ad->frameIdx = 0;
					ad->frameTime = 0.0f;
				}
			} else {
				if( ad->anim != &girlJumpDown ) {
					ad->anim = &girlJumpDown;
					ad->frameIdx = 0;
					ad->frameTime = 0.0f;
				}
			}
		} else {
			float spd = fabsf( pd->vel.x );
			if( spd >= ( maxSpeed * 0.8f ) ) {
				if( ad->anim != &girlRun ) {
					if( ad->anim != &girlWalk ) {
						ad->frameIdx = 0;
						ad->frameTime = 0.0f;
					}
					ad->anim = &girlRun;
				}
			} else if( spd > 0.0f ) {
				if( ad->anim != &girlWalk ) {
					if( ad->anim != &girlRun ) {
						ad->frameIdx = 0;
						ad->frameTime = 0.0f;
					}
					ad->anim = &girlWalk;
				}
			} else {
				if( ad->anim != &girlIdle ) {
					ad->anim = &girlIdle;
					ad->frameIdx = 0;
					ad->frameTime = 0.0f;
				}
			}
		}
	}

	if( resetPressedDown ) {
		genericDestoryObject( entity );
	}
}

void zombieAI( const Entity* entity )
{
	/*
	Walk forward until we hit something or would walk off a cliff.
	Walk through other zombies.
	*/

	ZombieAIData* aiData;
	PhysicsData* physicsData;
	PosData* posData;

	ecps_GetComponentFromEntity( entity, gameECPSSetup.zombieAIComp, &aiData );
	ecps_GetComponentFromEntity( entity, gameECPSSetup.physicsComp, &physicsData );
	ecps_GetComponentFromEntity( entity, gameECPSSetup.posComp, &posData );

	bool turnAround = false;
	if( fabsf( aiData->lastPos.x - posData->futurePos.x ) < 0.0001f ) {
		turnAround = true;
	}
	aiData->lastPos = posData->futurePos;

	// checkk to see if we're about to walk off an edge
	Vector2 checkStart = vec2( posData->futurePos.x + ( aiData->turnCheckDist * aiData->direction ), posData->futurePos.y );
	Vector2 checkEnd;

	vec2_AddScaled( &checkStart, &VEC2_DOWN, BASE_SIZE.y, &checkEnd );

	ColliderCollection staticColliders;
	staticColliders.stride = sizeof( sbStaticColliders[0] );
	staticColliders.firstCollider = &( sbStaticColliders[0].coll );
	staticColliders.count = sb_Count( sbStaticColliders );

	if( collision_RayCast( checkStart, checkEnd, staticColliders, NULL ) == 0 ) {
		turnAround = true;
	}

	if( turnAround ) {
		aiData->direction *= -1.0f;
	}

	float acc = BASE_SIZE.x * ( 100.0f / 32.0f );
	if( physicsData->timeOffGround <= 0.0f ) {
		if( ( physicsData->vel.x * aiData->direction ) < 0.0f ) {
			// changing direction
			acc = BASE_SIZE.x * ( 200.0f / 32.0f );;
		}

		physicsData->vel.x += ( aiData->direction * acc ) * deltaTime;
		if( fabsf( physicsData->vel.x ) >= aiData->maxSpeed ) {
			physicsData->vel.x = aiData->direction * aiData->maxSpeed;
		}
	}

	// update animation playing and direction
	RenderData* rd = NULL;
	AnimatedData* ad = NULL;

	ecps_GetComponentFromEntity( entity, gameECPSSetup.renderComp, &rd );
	ecps_GetComponentFromEntity( entity, gameECPSSetup.animatedComp, &ad );
	if( rd && ad ) {
		if( physicsData->vel.x < 0.0f ) {
			rd->scale.x = -fabsf( rd->scale.x );
		} else if( physicsData->vel.x > 0.0f ) {
			rd->scale.x = fabsf( rd->scale.x );
		}

		float spd = fabsf( physicsData->vel.x );
		if( spd > 0.0f ) {
			if( ad->anim != aiData->walkAnim ) {
				ad->anim = aiData->walkAnim;
				ad->frameIdx = 0;
				ad->frameTime = 0.0f;
			}
		} else {
			if( ad->anim != aiData->idleAnim ) {
				ad->anim = aiData->idleAnim;
				ad->frameIdx = 0;
				ad->frameTime = 0.0f;
			}
		}
	}
}

static void adjustChildrenPos( const Entity* entity, Vector2 offset )
{
	AttachableData* ad = NULL;
	ecps_GetComponentFromEntity( entity, gameECPSSetup.attachableComp, &ad );
	assert( ad != NULL );

	EntityID currID = ad->firstChild;
	while( currID != INVALID_ENTITY ) {
		Entity child;
		PosData* childPos = NULL;
		AttachableData* childAttach = NULL;

		bool gotChild = ecps_GetEntityByID( &(gameECPSSetup.ecps), currID, &child );
		assert( gotChild );

		ecps_GetComponentFromEntity( &child, gameECPSSetup.posComp, &childPos );
		ecps_GetComponentFromEntity( &child, gameECPSSetup.attachableComp, &childAttach );
		assert( childPos != NULL );
		assert( childAttach != NULL );

		vec2_Add( &( childPos->futurePos ), &offset, &( childPos->futurePos ) );
		vec2_Add( &( childAttach->offset ), &offset, &( childAttach->offset ) );

		adjustChildrenPos( &child, offset );

		currID = childAttach->nextSibling;
	}
}

void physics( const Entity* entity )
{
	PhysicsData* pd;
	PosData* pos;

	ecps_GetComponentFromEntity( entity, gameECPSSetup.physicsComp, &pd );
	ecps_GetComponentFromEntity( entity, gameECPSSetup.posComp, &pos );

	// assuming 32p = 1.5 meters then gravity is ( 32 / 1.5 ) * 9.8 p
	pd->vel.y += ( ( BASE_SIZE.y / 1.5f ) * 9.8f ) * deltaTime;

	if( ecps_DoesEntityHaveComponent( entity, gameECPSSetup.dragFlagComp ) ) {
		float drag = pd->vel.x * 0.95f * deltaTime;
		if( fabsf( pd->vel.x ) <= fabsf( drag ) ) {
			pd->vel.x = 0.0f;
		} else {
			pd->vel.x -= drag;
		}
	}

	Vector2 offset;
	Vector2 vel = pd->vel;
	vec2_Scale( &vel, deltaTime, &offset );

	vec2_Add( &( pos->futurePos ), &offset, &( pos->futurePos ) );

	// adjust all children
	if( ecps_DoesEntityHaveComponent( entity, gameECPSSetup.attachableComp ) ) {
		adjustChildrenPos( entity, offset );
	}

	pd->timeOffGround += deltaTime;
}

static void upPressed( void )
{
	upDown = true;
}

static void upReleased( void )
{
	upDown = false;
}

static void downPressed( void )
{
	downDown = true;
}

static void downReleased( void )
{
	downDown= false;
}

static void leftPressed( void )
{
	leftDown = true;
}

static void leftReleased( void )
{
	leftDown = false;
}

static void rightPressed( void )
{
	rightDown = true;
}

static void rightReleased( void )
{
	rightDown = false;
}

static void resetPressed( void )
{
	resetPressedDown = true;
}

static void resetReleased( void )
{
	resetPressedDown = false;
}

static void generateDynamicColliderGroupStart( void )
{
	sb_Clear( sbDynamicColliders );
}

static void generateDynamicColliderGroup( const Entity* entity )
{
	PosData* pos = NULL;
	CollisionData* collData = NULL;

	ecps_GetComponentFromEntity( entity, gameECPSSetup.posComp, &pos );
	ecps_GetComponentFromEntity( entity, gameECPSSetup.dynamicCollisionComp, &collData );

	ColliderInfo coll;

	coll.entity = entity->id;
	coll.coll.type = CT_AABB;
	coll.coll.aabb.center = pos->futurePos;
	coll.coll.aabb.halfDim = collData->halfDim;

	sb_Push( sbDynamicColliders, coll );

	AttachableData* attachable;
	ecps_GetComponentFromEntity( entity, gameECPSSetup.attachableComp, &attachable );
	if( attachable != NULL ) {
		attachable->offset = VEC2_ZERO;
	}
}

static void collisionResponse_Vertical( int firstColliderIdx, int secondColliderIdx, Vector2 separation )
{
	sbDynamicColliders[firstColliderIdx].coll.aabb.center.y += separation.y;

	if( fabsf( separation.y ) > 0.01f ) {
		PhysicsData* pd = NULL;
		ecps_GetComponentFromEntityByID( &(gameECPSSetup.ecps), sbDynamicColliders[firstColliderIdx].entity, gameECPSSetup.physicsComp, &pd );
		pd->vel.y = 0.0f;
		
		if( separation.y < 0.0f ) {
			pd->timeOffGround = 0.0f;
		}
	}
}

static void collisionResponse_Horizontal( int firstColliderIdx, int secondColliderIdx, Vector2 separation )
{
	sbDynamicColliders[firstColliderIdx].coll.aabb.center.x += separation.x;

	if( ecps_DoesEntityHaveComponentByID( &(gameECPSSetup.ecps), sbDynamicColliders[firstColliderIdx].entity, gameECPSSetup.pushableFlagComp ) ) {
		int x = 0;
	}

	PhysicsData* pd = NULL;
	ecps_GetComponentFromEntityByID( &(gameECPSSetup.ecps), sbDynamicColliders[firstColliderIdx].entity, gameECPSSetup.physicsComp, &pd );
	pd->vel.x = 0.0f;
}

static void collisionResponse_DynamicVertical( int firstColliderIdx, int secondColliderIdx, Vector2 separation )
{
	if( separation.y == 0.0f ) return;

	int lowerIdx;
	int higherIdx;

	if( sbDynamicColliders[firstColliderIdx].coll.aabb.center.y < sbDynamicColliders[secondColliderIdx].coll.aabb.center.y ) {
		lowerIdx = secondColliderIdx;
		higherIdx = firstColliderIdx;
	} else {
		lowerIdx = firstColliderIdx;
		higherIdx = secondColliderIdx;
		// always want it so if we add the separation to the higher one it will offset
		separation.y = -separation.y;
	}

	Entity eLower, eHigher;
	ecps_GetEntityByID( &(gameECPSSetup.ecps), sbDynamicColliders[lowerIdx].entity, &eLower );
	ecps_GetEntityByID( &(gameECPSSetup.ecps), sbDynamicColliders[higherIdx].entity, &eHigher );

	PhysicsData* higherPhysics = NULL;
	PhysicsData* lowerPhysics = NULL;
	ecps_GetComponentFromEntity( &eHigher, gameECPSSetup.physicsComp, &higherPhysics );
	ecps_GetComponentFromEntity( &eLower, gameECPSSetup.physicsComp, &lowerPhysics );

	sbDynamicColliders[higherIdx].coll.aabb.center.y += separation.y;

	if( ecps_DoesEntityHaveComponent( &eLower, gameECPSSetup.canBeRiddenFlagComp ) && ecps_DoesEntityHaveComponent( &eHigher, gameECPSSetup.canRideFlagComp ) ) {
		// attach the higher to the lower
		attachEntity( &eLower, &eHigher );
		if( higherPhysics != NULL ) {
			higherPhysics->timeOffGround = 0.0f;
			higherPhysics->vel.y = 0.0f;
		}
	}

	if( ecps_DoesEntityHaveComponent( &eHigher, gameECPSSetup.canCrushFlagComp ) &&
		ecps_DoesEntityHaveComponent( &eLower, gameECPSSetup.crushableFlagComp ) ) {
		// KRUSHEN! or not...
		// we only want to do this if the crusher has downward momentum
		if( ( higherPhysics->vel.y > 0.0f ) && ( higherPhysics->timeOffGround >= 0.1f ) ) {
			ecps_AddComponentToEntity( &(gameECPSSetup.ecps), &eLower, gameECPSSetup.destroyFlagComp, NULL );
			spawnDeathParticles( sbDynamicColliders[lowerIdx].coll.aabb.center );
		} else {
			lowerPhysics->vel.y = 0.0f; // stop as if we hit a solid collision
		}
	}

	if( ecps_DoesEntityHaveComponent( &eHigher, gameECPSSetup.canKillPlayerComp ) && ecps_DoesEntityHaveComponent( &eLower, gameECPSSetup.playerInputComp ) ) {
		ecps_AddComponentToEntity( &(gameECPSSetup.ecps), &eLower, gameECPSSetup.destroyFlagComp, NULL );
		spawnDeathParticles( sbDynamicColliders[lowerIdx].coll.aabb.center );
	}
		  
	if( ecps_DoesEntityHaveComponent( &eHigher, gameECPSSetup.playerInputComp ) && ecps_DoesEntityHaveComponent( &eLower, gameECPSSetup.canKillPlayerComp ) ) {
		ecps_AddComponentToEntity( &(gameECPSSetup.ecps), &eHigher, gameECPSSetup.destroyFlagComp, NULL );
		spawnDeathParticles( sbDynamicColliders[higherIdx].coll.aabb.center );
	}
}

static void handlePushable( int pusher, int pushable, Entity* pushableEntity, float separation )
{
	PhysicsData* pushablePhysics;
	ecps_GetComponentFromEntity( pushableEntity, gameECPSSetup.physicsComp, &pushablePhysics );

	float oldPushableX = sbDynamicColliders[pushable].coll.aabb.center.x;
	sbDynamicColliders[pusher].coll.aabb.center.x += separation * 0.5f;
	sbDynamicColliders[pushable].coll.aabb.center.x -= separation * 0.5f;

	// adjust the velocity of the pushable
	pushablePhysics->vel.x = ( sbDynamicColliders[pushable].coll.aabb.center.x - oldPushableX ) / deltaTime;
}

static void handleHorizontalDynamicCollisions( int eOneIdx, int eTwoIdx, Entity* eOne, Entity* eTwo, float separation )
{
	// nothing is pushable, the objects should be separated an amount based on their respective horizontal velocities
	PhysicsData* pdOne;
	PhysicsData* pdTwo;

	ecps_GetComponentFromEntity( eOne, gameECPSSetup.physicsComp, &pdOne );
	ecps_GetComponentFromEntity( eTwo, gameECPSSetup.physicsComp, &pdTwo );

	float velOne = fabsf( pdOne->vel.x );
	float velTwo = fabsf( pdTwo->vel.x );
	float totalVel = velOne + velTwo;

	if( totalVel <= 0.0f ) {
		velOne = 1.0f;
		velTwo = 1.0f;
		totalVel = 2.0f;
	}
	sbDynamicColliders[eOneIdx].coll.aabb.center.x += separation * ( velOne / totalVel );
	sbDynamicColliders[eTwoIdx].coll.aabb.center.x -= separation * ( velTwo / totalVel );

	pdOne->vel.x = 0.0f;
	pdTwo->vel.x = 0.0f;
}

static void collisionResponse_DynamicHorizontal( int firstColliderIdx, int secondColliderIdx, Vector2 separation )
{
	if( separation.x == 0.0f ) return;

	// canPush/pushable
	//  if the object is pushable then check to see if the other canPush or not, if it can then push, otherwise
	//  treat as a solid collision
	Entity eOne;
	Entity eTwo;

	ecps_GetEntityByID( &(gameECPSSetup.ecps), sbDynamicColliders[firstColliderIdx].entity, &eOne );
	ecps_GetEntityByID( &(gameECPSSetup.ecps), sbDynamicColliders[secondColliderIdx].entity, &eTwo );

	/*PhysicsData* eOnePhysics = NULL;
	PhysicsData* eTwoPhysics = NULL;
	ecps_GetComponentFromEntity( &eOne, physicsComp, &eOnePhysics );
	ecps_GetComponentFromEntity( &eTwo, physicsComp, &eTwoPhysics );//*/

	if( ecps_DoesEntityHaveComponent( &eOne, gameECPSSetup.pushableFlagComp ) && ecps_DoesEntityHaveComponent( &eTwo, gameECPSSetup.canPushFlagComp ) ) {
		handlePushable( secondColliderIdx, firstColliderIdx, &eOne, -separation.x );
	} else if( ecps_DoesEntityHaveComponent( &eTwo, gameECPSSetup.pushableFlagComp ) && ecps_DoesEntityHaveComponent( &eOne, gameECPSSetup.canPushFlagComp ) ) {
		handlePushable( firstColliderIdx, secondColliderIdx, &eTwo, separation.x );
	} else if( ecps_DoesEntityHaveComponent( &eOne, gameECPSSetup.pushableFlagComp ) || ecps_DoesEntityHaveComponent( &eTwo, gameECPSSetup.pushableFlagComp ) ) {
		handleHorizontalDynamicCollisions( firstColliderIdx, secondColliderIdx, &eOne, &eTwo, separation.x );
	}

	if( ecps_DoesEntityHaveComponent( &eOne, gameECPSSetup.canKillPlayerComp ) && ecps_DoesEntityHaveComponent( &eTwo, gameECPSSetup.playerInputComp ) ) {
		ecps_AddComponentToEntity( &(gameECPSSetup.ecps), &eTwo, gameECPSSetup.destroyFlagComp, NULL );
		spawnDeathParticles( sbDynamicColliders[secondColliderIdx].coll.aabb.center );
	}
		  
	if( ecps_DoesEntityHaveComponent( &eOne, gameECPSSetup.playerInputComp ) && ecps_DoesEntityHaveComponent( &eTwo, gameECPSSetup.canKillPlayerComp ) ) {
		ecps_AddComponentToEntity( &(gameECPSSetup.ecps), &eOne, gameECPSSetup.destroyFlagComp, NULL );
		spawnDeathParticles( sbDynamicColliders[firstColliderIdx].coll.aabb.center );
	}
}

static void collisionResponse_Triggers( int firstColliderIdx, int secondColliderIdx, Vector2 separation )
{
	Entity eOne;
	Entity eTwo;

	ecps_GetEntityByID( &(gameECPSSetup.ecps), sbDynamicColliders[firstColliderIdx].entity, &eOne );
	ecps_GetEntityByID( &(gameECPSSetup.ecps), sbTriggerColliders[secondColliderIdx].entity, &eTwo );

	if( ecps_DoesEntityHaveComponent( &eTwo, gameECPSSetup.canKillAnythingComp ) ) {
		spawnDeathParticles( sbDynamicColliders[firstColliderIdx].coll.aabb.center );
		ecps_AddComponentToEntity( &(gameECPSSetup.ecps), &eOne, gameECPSSetup.destroyFlagComp, NULL );
	} else if( ecps_DoesEntityHaveComponent( &eTwo, gameECPSSetup.endLevelFlagComp ) && ecps_DoesEntityHaveComponent( &eOne, gameECPSSetup.playerInputComp ) ) {
		//llog( LOG_CRITICAL, "You are winnar!" );
		nextLevel = ( currLevel + 1 ) % sb_Count( sbLevels );

		// remove player input component and add winner ai component
		// remove killable stuff
		// add timer for despawn and load next level stuff
	}
}

static void runCollisions( void )
{
	ColliderCollection staticColliders;
	ColliderCollection dynamicColliders;
	ColliderCollection triggerColliders;

	staticColliders.stride = sizeof( sbStaticColliders[0] );
	staticColliders.firstCollider = &( sbStaticColliders[0].coll );
	staticColliders.count = sb_Count( sbStaticColliders );

	dynamicColliders.stride = sizeof( sbDynamicColliders[0] );
	dynamicColliders.firstCollider = &( sbDynamicColliders[0].coll );
	dynamicColliders.count = sb_Count( sbDynamicColliders );

	triggerColliders.stride = sizeof( sbTriggerColliders[0] );
	triggerColliders.firstCollider = &( sbTriggerColliders[0].coll );
	triggerColliders.count = sb_Count( sbTriggerColliders );

	// dynamic-dynamic collisions
	//  first vertical
	collision_DetectAllInternal( dynamicColliders, collisionResponse_DynamicVertical );
	//  then horizontal
	collision_DetectAllInternal( dynamicColliders, collisionResponse_DynamicHorizontal );

	// then do the dynamic-trigger collisions
	collision_DetectAll( dynamicColliders, triggerColliders, collisionResponse_Triggers );

	// do the dynamic-static collisions
	//  first only care about vertical collisions
	collision_DetectAll( dynamicColliders, staticColliders, collisionResponse_Vertical );

	//  second only care about horizontal collisions
	collision_DetectAll( dynamicColliders, staticColliders, collisionResponse_Horizontal );

	// now copy over the final positions to the entities
	float invDeltaTime = 1.0f / deltaTime;
	for( size_t i = 0; i < sb_Count( sbDynamicColliders ); ++i ) {
		Entity e;
		PosData* pos;
		AttachableData* attach;

		ecps_GetEntityByID( &(gameECPSSetup.ecps), sbDynamicColliders[i].entity, &e );
		ecps_GetComponentFromEntity( &e, gameECPSSetup.posComp, &pos );
		ecps_GetComponentFromEntity( &e, gameECPSSetup.attachableComp, &attach );

		Vector2 offset;
		if( pos != NULL ) {
			vec2_Subtract( &( sbDynamicColliders[i].coll.aabb.center ), &( pos->futurePos ), &offset );
			pos->futurePos = sbDynamicColliders[i].coll.aabb.center;

			if( attach != NULL ) {
				vec2_Add( &( pos->futurePos ), &( attach->offset ), &( pos->futurePos ) );
				vec2_Add( &offset, &( attach->offset ), &offset );
				adjustChildrenPos( &e, offset );
			}
		}
	}
}

static void cleanUpDeadEntities( const Entity* entity )
{
	llog( LOG_VERBOSE, "Destroying entity: %i", entity->id );
	ecps_DestroyEntity( &(gameECPSSetup.ecps), entity );
}

static void animationUpdate( const Entity* entity )
{
	AnimatedData* animData;
	RenderData* rd;

	ecps_GetComponentFromEntity( entity, gameECPSSetup.animatedComp, &animData );
	ecps_GetComponentFromEntity( entity, gameECPSSetup.renderComp, &rd );

	animData->frameTime += deltaTime;

	while( animData->frameTime > animData->anim->sbFrames[animData->frameIdx].duration ) {
		animData->frameTime -= animData->anim->sbFrames[animData->frameIdx].duration;

		++( animData->frameIdx );

		if( animData->frameIdx >= sb_Count( animData->anim->sbFrames ) ) {
			if( animData->anim->loops ) {
				animData->frameIdx = 0;
			} else {
				animData->frameIdx = sb_Count( animData->anim->sbFrames ) - 1;
				animData->frameTime = 0.0f;
			}
		}
	}

	rd->img = animData->anim->sbFrames[animData->frameIdx].img;
}

#define RELOAD_TIME 1.0f;
static float reloadTime = RELOAD_TIME;
static void resetReloadFlag( void )
{
	reloadTime -= deltaTime;
}

static void checkReload( const Entity* entity )
{
	reloadTime = RELOAD_TIME;
}

static Vector2 bgMin;
static Vector2 bgMax;
static Vector2 bgTest;
static void setupBG( float levelWidth, float levelHeight )
{
	Vector2 bgSize;
	img_GetSize( bgImg, &bgSize );

	int rwi;
	int rhi;
	gfx_GetRenderSize( &rwi, &rhi );

	vec2_AddScaled( &camMin, &bgSize, 0.5f, &bgMin );

	vec2_AddScaled( &camMax, &bgSize, -0.5f, &bgMax );
	bgMax.x += (float)rwi;
	bgMax.y += (float)rhi;

	if( bgMax.x < bgMin.x ) {
		bgMax.x = 0.0f;
		bgMin.x = 0.0f;
	}

	if( bgMax.y < bgMin.y ) {
		bgMax.y = 0.0f;
		bgMin.y = 0.0f;
	}
}

static void loadLevel( int idx )
{
	llog( LOG_DEBUG, "Loading level %i...", idx );
	currLevel = idx;

	//ecps_CleanUp( &gameECPS );
	ecps_DestroyAllEntities( &(gameECPSSetup.ecps) );
	sb_Clear( sbStaticColliders );
	sb_Clear( sbTriggerColliders );
	sb_Clear( sbDynamicColliders );

	// now parse the level data, creating the necessary entities
	//  we'll assume tiles are 32x32
	Vector2 tileSize = BASE_SIZE;
	Vector2 halfSize;
	vec2_Scale( &tileSize, 0.5f, &halfSize );

	// first find the total level width and height
	Vector2 topLeft;

	float levelWidth = sbLevels[idx].width * tileSize.w;
	float levelHeight = sbLevels[idx].height * tileSize.h;

	topLeft.x = -( levelWidth / 2.0f );
	topLeft.y = -( levelHeight / 2.0f );

	vec2_AddScaled( &topLeft, &tileSize, -0.5f, &camMin );
	vec2_AddScaled( &topLeft, &tileSize, 0.5f, &camMax );
	vec2_Scale( &camMax, -1.0f, &camMax );

	Vector2 borderPos = { 0.0f, 0.0f };
	ColliderInfo borderCollider;
	borderCollider.entity = INVALID_ENTITY;

	// first get the physical borders based on the camera borders
	borderPos.x = camMin.x;
	collision_CalculateHalfSpace( &borderPos, &VEC2_RIGHT, &( borderCollider.coll ) );
	sb_Push( sbStaticColliders, borderCollider );

	borderPos.x = camMax.x;
	collision_CalculateHalfSpace( &borderPos, &VEC2_LEFT, &( borderCollider.coll ) );
	sb_Push( sbStaticColliders, borderCollider );

	// bottom death trigger
	Entity deathFloor;
	ecps_CreateEntity( &(gameECPSSetup.ecps), &deathFloor, 1, gameECPSSetup.canKillAnythingComp );
	borderPos.x = 0.0f;
	borderPos.y = camMax.y;
	collision_CalculateHalfSpace( &borderPos, &VEC2_UP, &( borderCollider.coll ) );
	borderCollider.entity = deathFloor.id;
	sb_Push( sbTriggerColliders, borderCollider );

	// now adjust the camera borders to take the actual camera size into account
	int rwi;
	int rhi;
	gfx_GetRenderSize( &rwi, &rhi );
	float renderWidth = (float)rwi;
	float renderHeight = (float)rhi;
	float halfRenderWidth = renderWidth / 2.0f;
	float halfRenderHeight = renderHeight / 2.0f;
	camMax.x -= renderWidth;
	if( camMax.x <= camMin.x ) {
		camMax.x = camMin.x = -halfRenderWidth;
	}

	camMax.y -= renderHeight;
	if( camMax.y <= camMin.y < 0 ) {
		camMax.y = camMin.y = -halfRenderHeight;
	}//*/

	// set up the parallax background
	setupBG( levelWidth, levelHeight );
	
	// generate the tiles
	LevelTile* levelTiles = sbLevels[idx].tileLayout;
	for( uint32_t y = 0; y < sbLevels[idx].height; ++y ) {
		for( uint32_t x = 0; x < sbLevels[idx].width; ++x ) {

			int tileIdx = x + ( y * sbLevels[idx].width );
			if( sbLevels[idx].tileLayout[tileIdx].inUse ) {
				Vector2 pos = vec2( ( topLeft.x + ( tileSize.w * x ) ), ( topLeft.y + ( tileSize.h * y ) ) );
				TileImage ti = tileImages[sbLevels[idx].tileLayout[tileIdx].img];

				createTile( &gameECPSSetup, pos, ti.img, sbLevels[idx].tileLayout[tileIdx].flipped ? -1.0f : 1.0f, ti.collOffset, ti.collSize );
			}
		}
	}

	// generate the objects
	for( uint32_t i = 0; i < sbLevels[idx].numObjects; ++i ) {
		
		Vector2 pos = vec2( ( topLeft.x + ( tileSize.w * sbLevels[idx].objectLayout[i].xCoord ) ), ( topLeft.y + ( tileSize.h * sbLevels[idx].objectLayout[i].yCoord ) ) );
		objectTypes[ sbLevels[idx].objectLayout[i].objectType ].create( &gameECPSSetup, pos );
	}

	// setup the static and trigger collisions
	ecps_RunProcess( &(gameECPSSetup.ecps), &addToStaticCollisionListProc );
	ecps_RunProcess( &(gameECPSSetup.ecps), &addToTriggerCollisionListProc );
}

static void addToStaticCollisionList( const Entity* entity )
{
	ColliderInfo collInfo;

	PosData* pos;
	CollisionData* coll;
	StaticCollisionOffset* offset;

	ecps_GetComponentFromEntity( entity, gameECPSSetup.posComp, &pos );
	ecps_GetComponentFromEntity( entity, gameECPSSetup.staticCollisionComp, &coll );
	ecps_GetComponentFromEntity( entity, gameECPSSetup.staticCollisionOffsetComp, &offset );

	collInfo.entity = entity->id;
	collInfo.coll.type = CT_AABB;
	vec2_Add( &(pos->futurePos), &(offset->offset), &(collInfo.coll.aabb.center) );
	collInfo.coll.aabb.halfDim = coll->halfDim;

	sb_Push( sbStaticColliders, collInfo );
}

static void addToTriggerCollisionList( const Entity* entity )
{
	ColliderInfo collInfo;

	PosData* pos;
	CollisionData* coll;

	ecps_GetComponentFromEntity( entity, gameECPSSetup.posComp, &pos );
	ecps_GetComponentFromEntity( entity, gameECPSSetup.triggerCollisionComp, &coll );

	collInfo.entity = entity->id;
	collInfo.coll.type = CT_AABB;
	collInfo.coll.aabb.center = pos->futurePos;
	collInfo.coll.aabb.halfDim = coll->halfDim;

	sb_Push( sbTriggerColliders, collInfo );
}

static int gameScreen_Enter( void )
{
	cam_TurnOnFlags( 0, 1 );
	// position the camera so the center of the screen is at (0,0)
	Vector2 camPos = { -400.0f, -300.0f };
	cam_SetState( 0, camPos, 1.0f );
	
	gfx_SetClearColor( CLR_BLACK );

	particles_Init( );

	ecps_StartInitialization( &(gameECPSSetup.ecps) ); {
		// components
		gameECPSSetup.posComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "Position", sizeof( PosData ), NULL );
		gameECPSSetup.physicsComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "Physics", sizeof( PhysicsData ), NULL );
		gameECPSSetup.playerInputComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "Player Input", 0, NULL );
		gameECPSSetup.renderComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "Render", sizeof( RenderData ), NULL );
		gameECPSSetup.dynamicCollisionComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "Collision", sizeof( CollisionData ), NULL );
		gameECPSSetup.staticCollisionComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "Collision", sizeof( CollisionData ), NULL );
		gameECPSSetup.triggerCollisionComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "Collision", sizeof( CollisionData ), NULL );
		gameECPSSetup.pushableFlagComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "CanBePushed", 0, NULL );
		gameECPSSetup.canPushFlagComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "CanPush", 0, NULL );
		gameECPSSetup.crushableFlagComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "CanBeCrushed", 0, NULL );
		gameECPSSetup.canCrushFlagComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "CanCrush", 0, NULL );
		gameECPSSetup.canKillPlayerComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "CanKillPlayer", 0, NULL );
		gameECPSSetup.canKillAnythingComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "KillAnything", 0, NULL );
		gameECPSSetup.endLevelFlagComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "EndsLevel", 0, NULL );
		gameECPSSetup.dragFlagComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "Drag", 0, NULL );
		gameECPSSetup.destroyFlagComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "Destroy", 0, NULL );
		gameECPSSetup.reloadOnDeathFlagComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "ReloadOnDeath", 0, NULL );
		gameECPSSetup.zombieAIComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "ZombieAI", sizeof( ZombieAIData ), NULL );
		gameECPSSetup.animatedComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "Animated", sizeof( AnimatedData ), NULL );
		gameECPSSetup.attachableComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "Attachable", sizeof( AttachableData ), NULL );
		gameECPSSetup.canRideFlagComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "CanRide", 0, NULL );
		gameECPSSetup.canBeRiddenFlagComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "CanBeRidden", 0, NULL );
		gameECPSSetup.renderOffsetComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "RenderOffset", sizeof( RenderOffset ), NULL );
		gameECPSSetup.objectTypeIdxComp = INVALID_COMPONENT_ID;
		gameECPSSetup.staticCollisionOffsetComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "StaticCollOffset", sizeof( StaticCollisionOffset ), NULL );
		gameECPSSetup.doNotRenderInGameFlagComp = ecps_AddComponentType( &(gameECPSSetup.ecps), "DoNotRender", 0, NULL );

		// Processes
		ecps_CreateProcess( &(gameECPSSetup.ecps), "Render", NULL, render, NULL, &renderProc, 2, gameECPSSetup.posComp, gameECPSSetup.renderComp );
		ecps_CreateProcess( &(gameECPSSetup.ecps), "Input", NULL, playerInput, NULL, &inputProc, 3, gameECPSSetup.physicsComp, gameECPSSetup.playerInputComp, gameECPSSetup.posComp );
		ecps_CreateProcess( &(gameECPSSetup.ecps), "Physics", NULL, physics, NULL, &physicsProc, 2, gameECPSSetup.posComp, gameECPSSetup.physicsComp );
		ecps_CreateProcess( &(gameECPSSetup.ecps), "Camera", NULL, positionCamera, NULL, &cameraProc, 2, gameECPSSetup.posComp, gameECPSSetup.playerInputComp );
		ecps_CreateProcess( &(gameECPSSetup.ecps), "Collision",
			generateDynamicColliderGroupStart, generateDynamicColliderGroup, runCollisions, &collisionProc,
			3, gameECPSSetup.posComp, gameECPSSetup.physicsComp, gameECPSSetup.dynamicCollisionComp );
		ecps_CreateProcess( &(gameECPSSetup.ecps), "CleanUp", NULL, cleanUpDeadEntities, NULL, &cleanUpProc, 1, gameECPSSetup.destroyFlagComp );
		ecps_CreateProcess( &(gameECPSSetup.ecps), "CheckReload", resetReloadFlag, checkReload, NULL, &checkReloadProc, 1, gameECPSSetup.reloadOnDeathFlagComp );
		ecps_CreateProcess( &(gameECPSSetup.ecps), "ZombieAI", NULL, zombieAI, NULL, &zombieAIProc, 3, gameECPSSetup.zombieAIComp, gameECPSSetup.physicsComp, gameECPSSetup.posComp );
		ecps_CreateProcess( &(gameECPSSetup.ecps), "Animated", NULL, animationUpdate, NULL, &animatedProc, 2, gameECPSSetup.animatedComp, gameECPSSetup.renderComp );
		ecps_CreateProcess( &(gameECPSSetup.ecps), "DetachEverything", NULL, detachAllChildren, NULL, &detachEverythingProc, 1, gameECPSSetup.attachableComp );

		ecps_CreateProcess( &(gameECPSSetup.ecps), "DrawDynamicColliders", NULL, collisionRender, NULL, &drawDynamicCollidersProc, 2, gameECPSSetup.dynamicCollisionComp, gameECPSSetup.posComp );
		ecps_CreateProcess( &(gameECPSSetup.ecps), "DrawAttachments", NULL, attachmentRender, NULL, &drawAttachmentsProc, 2, gameECPSSetup.posComp, gameECPSSetup.attachableComp );

		ecps_CreateProcess( &(gameECPSSetup.ecps), "GenStatic", NULL, addToStaticCollisionList, NULL, &addToStaticCollisionListProc, 3,
			gameECPSSetup.posComp, gameECPSSetup.staticCollisionComp, gameECPSSetup.staticCollisionOffsetComp );
		ecps_CreateProcess( &(gameECPSSetup.ecps), "GenTrigger", NULL, addToTriggerCollisionList, NULL, &addToTriggerCollisionListProc, 2,
			gameECPSSetup.posComp, gameECPSSetup.triggerCollisionComp );

	} ecps_FinishInitialization( &(gameECPSSetup.ecps) );

	loadLevel( 0 );
	nextLevel = 0;

	input_BindOnKeyPress( SDLK_LEFT, leftPressed );
	input_BindOnKeyRelease( SDLK_LEFT, leftReleased );

	input_BindOnKeyPress( SDLK_RIGHT, rightPressed );
	input_BindOnKeyRelease( SDLK_RIGHT, rightReleased );

	input_BindOnKeyPress( SDLK_UP, upPressed );
	input_BindOnKeyRelease( SDLK_UP, upReleased );

	input_BindOnKeyPress( SDLK_DOWN, downPressed );
	input_BindOnKeyRelease( SDLK_DOWN, downReleased );

	input_BindOnKeyPress( SDLK_r, resetPressed );
	input_BindOnKeyRelease( SDLK_r, resetReleased );

	return 1;
}

static int gameScreen_Exit( void )
{
	particles_CleanUp( );
	ecps_CleanUp( &(gameECPSSetup.ecps) );
	return 1;
}

static void gameScreen_ProcessEvents( SDL_Event* e )
{
}

static void gameScreen_Process( void )
{
}

static void gameScreen_Draw( void )
{
	ecps_RunProcess( &(gameECPSSetup.ecps), &cameraProc );
	ecps_RunProcess( &(gameECPSSetup.ecps), &renderProc );

	Vector2 bgStart;
	Vector2 bgEnd;
	cam_GetCurrPos( 0, &bgStart );
	cam_GetNextPos( 0, &bgEnd );

	bgStart.x = inverseLerp( camMin.x, camMax.x, bgStart.x );
	bgStart.x = lerp( bgMin.x, bgMax.x, bgStart.x );
	bgStart.y = inverseLerp( camMin.y, camMax.y, bgStart.y );
	bgStart.y = lerp( bgMin.y, bgMax.y, bgStart.y );
	
	bgEnd.x = inverseLerp( camMin.x, camMax.x, bgEnd.x );
	bgEnd.x = lerp( bgMin.x, bgMax.x, bgEnd.x );
	bgEnd.y = inverseLerp( camMin.y, camMax.y, bgEnd.y );
	bgEnd.y = lerp( bgMin.y, bgMax.y, bgEnd.y );

	img_Draw( bgImg, 1, bgStart, bgEnd, -10 );

	//debugRenderer_Circle( 1, VEC2_ZERO, 20.0f, CLR_MAGENTA );
	//ecps_RunProcess( &(gameECPSSetup.ecps), &drawAttachmentsProc );
	//ecps_RunProcess( &(gameECPSSetup.ecps), &drawDynamicCollidersProc );
	/*ColliderCollection staticColls;
	staticColls.count = sb_Count( sbStaticColliders );
	staticColls.firstCollider = &( sbStaticColliders[0].coll );
	staticColls.stride = sizeof( sbStaticColliders[0] );
	collision_CollectionDebugDrawing( staticColls, 1, CLR_BLUE );//*/
}

static void gameScreen_PhysicsTick( float dt )
{
	deltaTime = dt;
	ecps_RunProcess( &(gameECPSSetup.ecps), &inputProc );
	ecps_RunProcess( &(gameECPSSetup.ecps), &zombieAIProc );

	ecps_RunProcess( &(gameECPSSetup.ecps), &physicsProc );
	ecps_RunProcess( &(gameECPSSetup.ecps), &detachEverythingProc );
	ecps_RunProcess( &(gameECPSSetup.ecps), &collisionProc );

	ecps_RunProcess( &(gameECPSSetup.ecps), &cleanUpProc );
	ecps_RunProcess( &(gameECPSSetup.ecps), &animatedProc );

	ecps_RunProcess( &(gameECPSSetup.ecps), &checkReloadProc );
	if( reloadTime <= 0.0f ) {
		loadLevel( currLevel );
	}

	if( currLevel != nextLevel ) {
		loadLevel( nextLevel );
	}
}

struct GameState gameScreenState = { gameScreen_Enter, gameScreen_Exit, gameScreen_ProcessEvents,
	gameScreen_Process, gameScreen_Draw, gameScreen_PhysicsTick };