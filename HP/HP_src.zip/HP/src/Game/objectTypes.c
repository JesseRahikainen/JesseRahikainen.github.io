#include "objectTypes.h"

#include "../Graphics/images.h"
#include "resources.h"
#include "../collisionDetection.h"
#include "../Utils/helpers.h"
#include "../Utils/stretchybuffer.h"

// TODO: Better way to set index of object type
ObjectType objectTypes[] = {
	{ "Crate",				createCrate },				// 0
	{ "Spawn",				createPlayer },				// 1
	{ "Strong Zombie",		createStrongZombie },		// 2
	{ "Fast Zombie",		createFastZombie },			// 3
	{ "Kill Trigger",		createKillTrigger },		// 4
	{ "End Level Trigger",	createEndLevelTrigger },	// 5
	{ "Arrow Sign",			createArrowSignSprite },	// 6
	{ "Bush 0",				createBush0Sprite },		// 7
	{ "Bush 1",				createBush1Sprite },		// 8
	{ "Dead Bush",			createDeadBushSprite },		// 9
	{ "Buried 0",			createDeco0Sprite },		// 10
	{ "Buried 1",			createDeco1Sprite },		// 11
	{ "Buried 2",			createDeco2Sprite },		// 12
	{ "Buried 3",			createDeco3Sprite },		// 13
	{ "Sign",				createSignSprite },			// 14
	{ "Skeleton",			createSkeletonSprite },		// 15
	{ "Tombstone 0",		createTombstone0Sprite },	// 16
	{ "Tombstone 1",		createTombstone1Sprite },	// 17
	{ "Tree",				createTreeSprite },			// 18
};

TileImage tileImages[] = {
	{ "Images/Tiles/ground0.png",		-1,	{ 0.0f, 0.0f },				{ BASE, BASE } },				// 0
	{ "Images/Tiles/ground1.png",		-1,	{ 0.0f, 0.0f },				{ BASE, BASE } },				// 1
	{ "Images/Tiles/ground2.png",		-1,	{ 0.0f, 0.0f },				{ BASE, BASE } },				// 2
	{ "Images/Tiles/ground3.png",		-1,	{ 0.0f, 0.0f },				{ BASE, BASE } },				// 3
	{ "Images/Tiles/ground4.png",		-1,	{ 0.0f, 0.0f },				{ BASE, BASE } },				// 4
	{ "Images/Tiles/ground5.png",		-1,	{ 0.0f, 0.0f },				{ BASE, BASE } },				// 5
	{ "Images/Tiles/ground6.png",		-1,	{ 0.0f, 0.0f },				{ BASE, BASE } },				// 6
	{ "Images/Tiles/ground7.png",		-1,	{ 0.0f, 0.0f },				{ BASE, BASE } },				// 7
	{ "Images/Tiles/ground8.png",		-1,	{ 0.0f, 0.0f },				{ BASE, BASE } },				// 8
	{ "Images/Tiles/ground9.png",		-1,	{ 0.0f, 0.0f },				{ BASE, BASE } },				// 9
	{ "Images/Tiles/ground10.png",		-1,	{ 0.0f, 0.0f },				{ BASE, BASE } },				// 10
	{ "Images/Tiles/ground11.png",		-1,	{ 0.0f, 0.0f },				{ BASE, BASE } },				// 11
	{ "Images/Tiles/ground12.png",		-1,	{ 0.0f, 0.0f },				{ BASE, BASE } },				// 12
	{ "Images/Tiles/ground13.png",		-1,	{ 0.0f, 0.0f },				{ BASE, BASE } },				// 13
	{ "Images/Tiles/platform0.png",		-1,	{ 0.0f, -( BASE / 4.0f ) },	{ BASE, ( BASE / 2.0f ) } },	// 14
	{ "Images/Tiles/platform1.png",		-1,	{ 0.0f, -( BASE / 4.0f ) },	{ BASE, BASE / 2.0f } },		// 15
	{ "Images/white.png",				-1,	{ 0.0f, 0.0f },				{ BASE, BASE } },				// 16
};

EntityID createKillTrigger( ECPSSetup* setup, Vector2 pos )
{
	Entity newEntity;
	ecps_CreateEntity( &(setup->ecps), &newEntity, 5,
		setup->posComp,
		setup->renderComp,
		setup->canKillAnythingComp,
		setup->triggerCollisionComp,
		setup->objectTypeIdxComp );

	// initialize the data
	PosData* posData = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->posComp, &posData ) ) {
		posData->currPos = pos;
		posData->futurePos = pos;
	}

	Vector2 size = BASE_SIZE;
	Vector2 imgSize;
	Vector2 scale;
	img_GetSize( whiteSquare, &imgSize );
	scale.x = size.x / imgSize.x;
	scale.y = size.y / imgSize.y;
	RenderData* rd = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->renderComp, &rd ) ) {
		rd->scale = scale;
		rd->clr = CLR_LIGHT_GREY;
		rd->img = whiteSquare;
		rd->depth = 0;
	}

	CollisionData* collData;
	if( ecps_GetComponentFromEntity( &newEntity, setup->triggerCollisionComp, &collData ) ) {
		vec2_Scale( &size, 0.5f, &(collData->halfDim) );
	}

	ObjectTypeIndex* objType = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->objectTypeIdxComp, &objType ) ) {
		objType->idx = 4;
	}

	return newEntity.id;
}

EntityID createEndLevelTrigger( ECPSSetup* setup, Vector2 pos )
{
	Entity newEntity;
	ecps_CreateEntity( &(setup->ecps), &newEntity, 6,
		setup->posComp,
		setup->renderComp,
		setup->endLevelFlagComp,
		setup->triggerCollisionComp,
		setup->objectTypeIdxComp,
		setup->doNotRenderInGameFlagComp );

	// initialize the data
	PosData* posData = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->posComp, &posData ) ) {
		posData->currPos = pos;
		posData->futurePos = pos;
	}

	Vector2 size = BASE_SIZE;
	Vector2 imgSize;
	Vector2 scale;
	img_GetSize( whiteSquare, &imgSize );
	scale.x = size.x / imgSize.x;
	scale.y = size.y / imgSize.y;
	RenderData* rd = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->renderComp, &rd ) ) {
		rd->scale = scale;
		rd->clr = CLR_MAGENTA;
		rd->img = whiteSquare;
		rd->depth = 0;
	}

	CollisionData* collData;
	if( ecps_GetComponentFromEntity( &newEntity, setup->triggerCollisionComp, &collData ) ) {
		vec2_Scale( &size, 0.5f, &(collData->halfDim) );
	}

	ObjectTypeIndex* objType = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->objectTypeIdxComp, &objType ) ) {
		objType->idx = 5;
	}

	return newEntity.id;
}

static EntityID createSprite( int img, float height, ECPSSetup* setup, Vector2 pos, float yOffset, int8_t depth, uint32_t idx )
{
	Entity newEntity;
	ecps_CreateEntity( &(setup->ecps), &newEntity, 4,
		setup->posComp,
		setup->renderComp,
		setup->renderOffsetComp,
		setup->objectTypeIdxComp);

	PosData* posData = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->posComp, &posData ) ) {
		//pos.y += yOffset;
		posData->currPos = pos;
		posData->futurePos = pos;
	}

	RenderData* rd = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->renderComp, &rd ) ) {
		Vector2 imgSize;
		Vector2 scale;
		rd->img = img;
		img_GetSize( rd->img, &imgSize );
		scale.y = height / imgSize.y;
		scale.x = scale.y;
		rd->scale = scale;
		rd->clr = CLR_WHITE;
		rd->depth = depth;
	}

	RenderOffset* offset = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->renderOffsetComp, &offset ) ) {
		offset->yOffset = yOffset;
	}

	ObjectTypeIndex* objType = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->objectTypeIdxComp, &objType ) ) {
		objType->idx = idx;
	}

	return newEntity.id;
}

EntityID createArrowSignSprite( ECPSSetup* setup, Vector2 pos )
{
	return createSprite( arrowSignImg, BASE_SIZE.y, setup, pos, 0.0f, -1, 6 );
}

EntityID createBush0Sprite( ECPSSetup* setup, Vector2 pos )
{
	return createSprite( bush0Img, BASE_SIZE.y, setup, pos, 1.0f, -1, 7 );
}

EntityID createBush1Sprite( ECPSSetup* setup, Vector2 pos )
{
	return createSprite( bush1Img, BASE_SIZE.y, setup, pos, 1.0f, -1, 8 );
}

EntityID createDeadBushSprite( ECPSSetup* setup, Vector2 pos )
{
	return createSprite( deadBushImg, BASE_SIZE.y, setup, pos, 0.0f, -1, 9 );
}

EntityID createDeco0Sprite( ECPSSetup* setup, Vector2 pos )
{
	return createSprite( deco0Img, BASE_SIZE.y, setup, pos, 0.0f, 1, 10 );
}

EntityID createDeco1Sprite( ECPSSetup* setup, Vector2 pos )
{
	return createSprite( deco1Img, BASE_SIZE.y, setup, pos, 0.0f, 1, 11 );
}

EntityID createDeco2Sprite( ECPSSetup* setup, Vector2 pos )
{
	return createSprite( deco2Img, BASE_SIZE.y, setup, pos, 0.0f, 1, 12 );
}

EntityID createDeco3Sprite( ECPSSetup* setup, Vector2 pos )
{
	return createSprite( deco3Img, BASE_SIZE.y, setup, pos, 0.0f, 1, 13 );
}

EntityID createSignSprite( ECPSSetup* setup, Vector2 pos )
{
	return createSprite( signImg, BASE_SIZE.y, setup, pos, 0.0f, -1, 14 );
}

EntityID createSkeletonSprite( ECPSSetup* setup, Vector2 pos )
{
	return createSprite( skeletonImg, BASE_SIZE.y * 0.5f, setup, pos, 17.0f, -1, 15 );
}

EntityID createTombstone0Sprite( ECPSSetup* setup, Vector2 pos )
{
	return createSprite( tombStone0Img, BASE_SIZE.y, setup, pos, 0.0f, -1, 16 );
}

EntityID createTombstone1Sprite( ECPSSetup* setup, Vector2 pos )
{
	return createSprite( tombStone1Img, BASE_SIZE.y * 1.5f, setup, pos, -( BASE_SIZE.y * 0.25f ), -1, 17 );
}

EntityID createTreeSprite( ECPSSetup* setup, Vector2 pos )
{
	float height = BASE_SIZE.y * 4.5f;
	return createSprite( treeImg, height, setup, pos, -( ( height * 0.5f ) - ( BASE_SIZE.y * 0.5f ) ), -1, 18 );
}

EntityID createCrate( ECPSSetup* setup, Vector2 pos )
{
	Entity newEntity;
	ecps_CreateEntity( &(setup->ecps), &newEntity, 11,
		setup->posComp,
		setup->renderComp,
		setup->pushableFlagComp,
		setup->canCrushFlagComp,
		setup->dragFlagComp,
		setup->physicsComp,
		setup->canRideFlagComp,
		setup->canBeRiddenFlagComp,
		setup->attachableComp,
		setup->dynamicCollisionComp,
		setup->objectTypeIdxComp );

	// initialize the data
	PosData* globalPosData = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->posComp, &globalPosData ) ) {
		globalPosData->currPos = pos;
		globalPosData->futurePos = pos;
	}

	AttachableData* attachableData = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->attachableComp, &attachableData ) ) {
		attachableData->firstChild = INVALID_ENTITY;
		attachableData->nextSibling = INVALID_ENTITY;
		attachableData->parent = INVALID_ENTITY;
	}

	Vector2 baseSizeAdj = { ( 32.0f / 32.0f ), ( 32.0f / 32.0f ) };
	Vector2 size;
	vec2_HadamardProd( &BASE_SIZE, &baseSizeAdj, &size );
	Vector2 imgSize;
	Vector2 scale;
	img_GetSize( crateImg, &imgSize );
	RenderData* rd = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->renderComp, &rd ) ) {
		scale.x = size.x / imgSize.x;
		scale.y = size.y / imgSize.y;
		rd->clr = CLR_WHITE;
		rd->scale = scale;
		rd->img = crateImg;
		rd->depth = 1;
	}

	PhysicsData* pd = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->physicsComp, &pd ) ) {
		pd->vel = VEC2_ZERO;
		pd->timeOffGround = 0.0f;
	}

	CollisionData* cd = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->dynamicCollisionComp, &cd ) ) {
		vec2_Scale( &size, 0.5f, &( cd->halfDim ) );
	}

	ObjectTypeIndex* objType = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->objectTypeIdxComp, &objType ) ) {
		objType->idx = 0;
	}

	return newEntity.id;
}

EntityID createPlayer( ECPSSetup* setup, Vector2 pos )
{
	Entity newEntity;
	ecps_CreateEntity( &(setup->ecps), &newEntity, 12,
		setup->posComp,
		setup->renderComp,
		setup->playerInputComp,
		setup->physicsComp,
		setup->dynamicCollisionComp,
		setup->canPushFlagComp,
		setup->crushableFlagComp,
		setup->reloadOnDeathFlagComp,
		setup->canRideFlagComp,
		setup->animatedComp,
		setup->attachableComp,
		setup->objectTypeIdxComp );

	// initialize the data

	Vector2 baseSizeAdj = { ( 16.0f / 32.0f ), ( 30.0f / 32.0f ) };
	Vector2 size;
	vec2_HadamardProd( &BASE_SIZE, &baseSizeAdj, &size );

	PosData* globalPosData = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->posComp, &globalPosData ) ) {
		globalPosData->currPos = pos;
		globalPosData->futurePos = pos;
	}

	AttachableData* attachableData = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->attachableComp, &attachableData ) ) {
		attachableData->firstChild = INVALID_ENTITY;
		attachableData->nextSibling = INVALID_ENTITY;
		attachableData->parent = INVALID_ENTITY;
	}

	RenderData* rd = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->renderComp, &rd ) ) {
		vec2_Scale( &BASE_SIZE, ( 0.08f / 32.0f ), &( rd->scale ) );
		rd->clr = CLR_WHITE;
		rd->img = whiteSquare;
		rd->depth = 2;
	}

	PhysicsData* pd = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->physicsComp, &pd ) ) {
		pd->vel = VEC2_ZERO;
		pd->timeOffGround = 0.0f;
	}

	CollisionData* cd = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->dynamicCollisionComp, &cd ) ) {
		vec2_Scale( &size, 0.5f, &( cd->halfDim ) );
	}

	AnimatedData* animatedData = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->animatedComp, &animatedData ) ) {
		animatedData->anim = &girlIdle;
		animatedData->frameIdx = 0;
		animatedData->frameTime = 0.0f;

		if( rd != NULL ) {
			rd->img = girlIdle.sbFrames[0].img;
		}
	}

	ObjectTypeIndex* objType = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->objectTypeIdxComp, &objType ) ) {
		objType->idx = 1;
	}

	return newEntity.id;
}

EntityID createStrongZombie( ECPSSetup* setup, Vector2 pos )
{
	Entity newEntity;
	ecps_CreateEntity( &(setup->ecps), &newEntity, 12,
		setup->posComp,
		setup->renderComp,
		setup->physicsComp,
		setup->dynamicCollisionComp,
		setup->crushableFlagComp,
		setup->canKillPlayerComp,
		setup->zombieAIComp,
		setup->animatedComp,
		setup->canPushFlagComp,
		setup->canRideFlagComp,
		setup->attachableComp,
		setup->objectTypeIdxComp );

	// initialize the data
	Vector2 baseSizeAdj = { ( 24.0f / 32.0f ), ( 32.0f / 32.0f ) };
	Vector2 size;
	vec2_HadamardProd( &BASE_SIZE, &baseSizeAdj, &size );

	PosData* globalPosData = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->posComp, &globalPosData ) ) {
		globalPosData->currPos = pos;
		globalPosData->futurePos = pos;
	}
	
	AttachableData* attachableData = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->attachableComp, &attachableData ) ) {
		attachableData->firstChild = INVALID_ENTITY;
		attachableData->nextSibling = INVALID_ENTITY;
		attachableData->parent = INVALID_ENTITY;
	}

	RenderData* rd = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->renderComp, &rd ) ) {
		rd->clr = CLR_WHITE;
		vec2_Scale( &BASE_SIZE, ( 0.08f / 32.0f ), &( rd->scale ) );
		rd->img = whiteSquare;
		rd->depth = 2;
	}

	PhysicsData* pd = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->physicsComp, &pd ) ) {
		pd->vel = VEC2_ZERO;
		pd->timeOffGround = 0.0f;
	}

	CollisionData* cd = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->dynamicCollisionComp, &cd ) ) {
		vec2_Scale( &size, 0.5f, &( cd->halfDim ) );
	}

	ZombieAIData* zombieAIData = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->zombieAIComp, &zombieAIData ) ) {
		zombieAIData->lastPos = pos;
		zombieAIData->direction = 1.0f;
		zombieAIData->idleAnim = &maleZombieIdle;
		zombieAIData->walkAnim = &maleZombieWalk;
		zombieAIData->maxSpeed = BASE_SIZE.x * ( 50.0f / 32.0f );
		zombieAIData->turnCheckDist = BASE_SIZE.x * ( 24.0f / 32.0f );
	}

	AnimatedData* animData = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->animatedComp, &animData ) ) {
		animData->anim = &maleZombieIdle;
		animData->frameIdx = 0;
		animData->frameTime = 0.0f;

		if( rd != NULL ) {
			rd->img = animData->anim->sbFrames[0].img;
		}
	}

	ObjectTypeIndex* objType = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->objectTypeIdxComp, &objType ) ) {
		objType->idx = 2;
	}

	return newEntity.id;
}

EntityID createFastZombie( ECPSSetup* setup, Vector2 pos )
{
	Entity newEntity;
	ecps_CreateEntity( &(setup->ecps), &newEntity, 11,
		setup->posComp,
		setup->renderComp,
		setup->physicsComp,
		setup->dynamicCollisionComp,
		setup->crushableFlagComp,
		setup->canKillPlayerComp,
		setup->zombieAIComp,
		setup->animatedComp,
		setup->canRideFlagComp,
		setup->attachableComp,
		setup->objectTypeIdxComp );

	// initialize the data
	Vector2 baseSizeAdj = { ( 24.0f / 32.0f ), ( 32.0f / 32.0f ) };
	Vector2 size;
	vec2_HadamardProd( &BASE_SIZE, &baseSizeAdj, &size );

	PosData* globalPosData = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->posComp, &globalPosData ) ) {
		globalPosData->currPos = pos;
		globalPosData->futurePos = pos;
	}

	AttachableData* attachableData = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->attachableComp, &attachableData ) ) {
		attachableData->firstChild = INVALID_ENTITY;
		attachableData->nextSibling = INVALID_ENTITY;
		attachableData->parent = INVALID_ENTITY;
	}

	RenderData* rd = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->renderComp, &rd ) ) {
		rd->clr = CLR_WHITE;
		vec2_Scale( &BASE_SIZE, ( 0.08f / 32.0f ), &( rd->scale ) );
		rd->img = whiteSquare;
		rd->depth = 2;
	}

	PhysicsData* pd = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->physicsComp, &pd ) ) {
		pd->vel = VEC2_ZERO;
		pd->timeOffGround = 0.0f;
	}

	CollisionData* cd = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->dynamicCollisionComp, &cd ) ) {
		vec2_Scale( &size, 0.5f, &( cd->halfDim ) );
	}

	ZombieAIData* zombieAIData = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->zombieAIComp, &zombieAIData ) ) {
		zombieAIData->lastPos = pos;
		zombieAIData->direction = 1.0f;
		zombieAIData->idleAnim = &femaleZombieIdle;
		zombieAIData->walkAnim = &femaleZombieWalk;
		zombieAIData->maxSpeed = BASE_SIZE.x * ( 100.0f / 32.0f );
		zombieAIData->turnCheckDist = BASE_SIZE.x * ( 36.0f / 32.0f );
	}

	AnimatedData* animData = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->animatedComp, &animData ) ) {
		animData->anim = &femaleZombieIdle;
		animData->frameIdx = 0;
		animData->frameTime = 0.0f;

		if( rd != NULL ) {
			rd->img = animData->anim->sbFrames[0].img;
		}
	}

	ObjectTypeIndex* objType = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->objectTypeIdxComp, &objType ) ) {
		objType->idx = 3;
	}

	return newEntity.id;
}

void loadTileImages( void )
{
	for( size_t i = 0; i < ARRAY_SIZE( tileImages ); ++i ) {
		tileImages[i].img = img_Load( tileImages[i].fileName, ST_DEFAULT );
	}
}

void createTile( ECPSSetup* setup, Vector2 pos, int img, float xScale, Vector2 collOffset, Vector2 collSize )
{
	Entity newEntity;
	ecps_CreateEntity( &(setup->ecps), &newEntity, 4,
		setup->posComp,
		setup->renderComp,
		setup->staticCollisionComp,
		setup->staticCollisionOffsetComp );

	// initialize the data
	PosData* posData = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->posComp, &posData ) ) {
		posData->currPos = pos;
		posData->futurePos = pos;
	}

	Vector2 size = BASE_SIZE;
	Vector2 imgSize;
	Vector2 scale;
	img_GetSize( img, &imgSize );
	scale.x = ( size.x / imgSize.x ) * xScale;
	scale.y = size.y / imgSize.y;
	RenderData* rd = NULL;
	if( ecps_GetComponentFromEntity( &newEntity, setup->renderComp, &rd ) ) {
		rd->scale = scale;
		rd->clr = CLR_WHITE;
		rd->img = img;
		rd->depth = 0;
	}

	CollisionData* collData;
	if( ecps_GetComponentFromEntity( &newEntity, setup->staticCollisionComp, &collData ) ) {
		vec2_Scale( &collSize, 0.5f, &(collData->halfDim) );
	}

	StaticCollisionOffset* offset;
	if( ecps_GetComponentFromEntity( &newEntity, setup->staticCollisionOffsetComp, &offset ) ) {
		offset->offset = collOffset;
	}
}

GLuint* getTileTextureIDs( void )
{
	GLuint* ids = NULL;

	for( int i = 0; i < ARRAY_SIZE( tileImages ); ++i ) {
		GLuint id;
		img_GetTextureID( tileImages[i].img, &id );
		sb_Push( ids, id );
	}

	return ids;
}

size_t numObjectTypes( void )
{
	return ARRAY_SIZE( objectTypes );
}