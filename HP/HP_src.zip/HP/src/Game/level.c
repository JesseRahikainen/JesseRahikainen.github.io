#include "level.h"

#include <stddef.h>
#include <SDL_rwops.h>

#include "../System/platformLog.h"
#include "../Utils/stretchyBuffer.h"
#include "../Utils/helpers.h"

// NOTE: This do not handle switching endianess correctly

/*typedef struct {
	int objectType;
	int xCoord;
	int yCoord;
} LevelObject;

typedef struct {
	int img;
	int flipped;
	int inUse;
} LevelTile;

typedef struct {
	char name[64];
	uint32_t width;
	uint32_t height;
	uint32_t numObjects;
	LevelTile* tileLayout;
	LevelObject* objectLayout;
} LevelDefinition; //*/

typedef struct {
	char name[64];
	uint32_t width;
	uint32_t height;
	uint32_t numObjects;
} LevelDefSave;

const char* FILE_PATH = "levels.dat";

LevelDefinition* sbLevels = NULL;

static void appendUInt32( uint8_t** sbData, uint32_t value )
{
	uint8_t bytes[4];
	bytes[0] = value & 0xFF;
	bytes[1] = ( value >> 8 ) & 0xFF;
	bytes[2] = ( value >> 16 ) & 0xFF;
	bytes[3] = ( value >> 24 ) & 0xFF;

	sb_Push( (*sbData), bytes[0] );
	sb_Push( (*sbData), bytes[1] );
	sb_Push( (*sbData), bytes[2] );
	sb_Push( (*sbData), bytes[3] );
}

static uint32_t readUInt32( uint8_t* sbData, size_t* currPos )
{
	uint8_t bytes[4];
	bytes[0] = sbData[(*currPos)++];
	bytes[1] = sbData[(*currPos)++];
	bytes[2] = sbData[(*currPos)++];
	bytes[3] = sbData[(*currPos)++];

	uint32_t data = bytes[0] | ( bytes[1] << 8 ) | ( bytes[2] << 16 ) | ( bytes[3] << 24 );
	return data;
}

static void appendStrN( uint8_t** sbData, const char* str, uint32_t len )
{
	appendUInt32( sbData, len );

	for( uint32_t i = 0; i < len; ++i ) {
		sb_Push( (*sbData), (uint8_t)str[i] );
	}
}

// we'll assume outBuffer is long enough
static void readStrN( uint8_t* sbData, size_t* currPos, char* outBuffer, uint32_t maxLen )
{
	uint32_t len = readUInt32( sbData, currPos );
	len = SDL_min( len, maxLen );

	for( uint32_t i = 0; i < len; ++i ) {
		outBuffer[i] = sbData[(*currPos)++];
	}
}

static void appendBool( uint8_t** sbData, bool value )
{
	uint8_t bv = value ? 1 : 0;
	sb_Push( (*sbData), bv );
}

static bool readBool( uint8_t* sbData, size_t* currPos )
{
	uint8_t bv = sbData[(*currPos)++];
	bool value = ( bv == 1 );
	return value;
}

void loadLevelsData( void )
{
	sb_Clear( sbLevels );

	SDL_RWops* rwopsFile = SDL_RWFromFile( FILE_PATH, "r" );
	if( rwopsFile == NULL ) {
		llog( LOG_CRITICAL, "Unable to open levels file: %s", SDL_GetError( ) );
		return;
	}

	uint8_t* sbBuffer = NULL;
	uint32_t bufferSize = (uint32_t)SDL_RWsize( rwopsFile );
	uint32_t amtRead = 1;
	uint32_t totalRead = 0;

	// read in all the data into the buffer
	sb_Add( sbBuffer, bufferSize );
	while( ( totalRead < bufferSize ) && ( amtRead != 0 ) ) {
		amtRead = SDL_RWread( rwopsFile, ( sbBuffer + totalRead ), sizeof( sbBuffer[0] ), bufferSize - totalRead );
		totalRead += amtRead;
	}

	if( totalRead != bufferSize ) {
		sb_Release( sbBuffer );
		llog( LOG_CRITICAL, "Error reading from file: %s", SDL_GetError( ) );
		return;
	}

	if( SDL_RWclose( rwopsFile ) < 0 ) {
		llog( LOG_CRITICAL, "Error closing file: %s", SDL_GetError( ) );
	}

	// parse the buffer
	size_t bufferPos = 0;
	uint32_t numLevels = readUInt32( sbBuffer, &bufferPos );

	// read in base definitions
	for( uint32_t i = 0; i < numLevels; ++i ) {
		LevelDefinition newDef;
		readStrN( sbBuffer, &bufferPos, newDef.name, ARRAY_SIZE( sbLevels[i].name ) );
		newDef.width = readUInt32( sbBuffer, &bufferPos );
		newDef.height = readUInt32( sbBuffer, &bufferPos );
		newDef.numObjects = readUInt32( sbBuffer, &bufferPos );

		sb_Push( sbLevels, newDef );
	}

	for( uint32_t i = 0; i < numLevels; ++i ) {
		// first tiles
		sbLevels[i].tileLayout = mem_Allocate( sizeof( sbLevels[i].tileLayout[0] ) * sbLevels[i].width * sbLevels[i].height );
		for( uint32_t x = 0; x < ( sbLevels[i].width * sbLevels[i].height ); ++x ) {
			sbLevels[i].tileLayout[x].img = readUInt32( sbBuffer, &bufferPos );
			sbLevels[i].tileLayout[x].inUse = readBool( sbBuffer, &bufferPos );
			sbLevels[i].tileLayout[x].flipped = readBool( sbBuffer, &bufferPos );
		}

		// then objects
		sbLevels[i].objectLayout = mem_Allocate( sizeof( sbLevels[i].objectLayout[0] ) * sbLevels[i].numObjects );
		for( uint32_t x = 0; x < sbLevels[i].numObjects; ++x ) {
			sbLevels[i].objectLayout[x].objectType = readUInt32( sbBuffer, &bufferPos );
			sbLevels[i].objectLayout[x].xCoord = readUInt32( sbBuffer, &bufferPos );
			sbLevels[i].objectLayout[x].yCoord = readUInt32( sbBuffer, &bufferPos );
		}
	}

	sb_Release( sbBuffer );
}

void saveLevelsData( void )
{
	uint8_t* sbBuffer = NULL;

	uint32_t numLevels = sb_Count( sbLevels );
	appendUInt32( &sbBuffer, numLevels );

	// save out base definitions
	for( uint32_t i = 0; i < numLevels; ++i ) {
		appendStrN( &sbBuffer, sbLevels[i].name, ARRAY_SIZE( sbLevels[i].name ) );
		appendUInt32( &sbBuffer, sbLevels[i].width );
		appendUInt32( &sbBuffer, sbLevels[i].height );
		appendUInt32( &sbBuffer, sbLevels[i].numObjects );
	}

	// save out array data
	for( uint32_t i = 0; i < numLevels; ++i ) {
		// first tiles
		for( uint32_t x = 0; x < ( sbLevels[i].width * sbLevels[i].height ); ++x ) {
			//sbLevels[i].tileLayout[x].flipped
			appendUInt32( &sbBuffer, sbLevels[i].tileLayout[x].img );
			appendBool( &sbBuffer, sbLevels[i].tileLayout[x].inUse );
			appendBool( &sbBuffer, sbLevels[i].tileLayout[x].flipped );
		}

		// then objects
		for( uint32_t x = 0; x < sbLevels[i].numObjects; ++x ) {
			appendUInt32( &sbBuffer, sbLevels[i].objectLayout[x].objectType );
			appendUInt32( &sbBuffer, sbLevels[i].objectLayout[x].xCoord );
			appendUInt32( &sbBuffer, sbLevels[i].objectLayout[x].yCoord );
		}
	}

	// write out all the data to the file
	uint32_t bufferSize = sb_Count( sbBuffer );

	SDL_RWops* rwopsFile = SDL_RWFromFile( FILE_PATH, "w" );
	if( rwopsFile == NULL ) {
		sb_Release( sbBuffer );
		llog( LOG_CRITICAL, "Unable to open levels file: %s", SDL_GetError( ) );
		return;
	}

	if( SDL_RWwrite( rwopsFile, sbBuffer, sizeof( sbBuffer[0] ), bufferSize ) < bufferSize ) {
		llog( LOG_CRITICAL, "Error writing out to file: %s", SDL_GetError( ) );
	}

	if( SDL_RWclose( rwopsFile ) < 0 ) {
		llog( LOG_CRITICAL, "Error closing file: %s", SDL_GetError( ) );
	}
}