#ifndef LEVEL_EDITOR_SCREEN_H
#define LEVEL_EDITOR_SCREEN_H

#include "../gameState.h"

struct GameState levelEditorScreenState;

#endif // inclusion guard