#include "levelEditorScreen.h"

#include <math.h>

#include "../Graphics/graphics.h"
#include "../Graphics/images.h"
#include "../Graphics/spineGfx.h"
#include "../Graphics/camera.h"
#include "../Graphics/debugRendering.h"
#include "../Graphics/imageSheets.h"
#include "../UI/text.h"
#include "../System/entityIDs.h"
#include "../particles.h"

#include "../System/ECPS/entityComponentProcessSystem.h"
#include "../collisionDetection.h"
#include "../Input/input.h"
#include "../Utils/stretchyBuffer.h"
#include "../System/platformLog.h"
#include "../Utils/helpers.h"

#include "../IMGUI/nuklearWrapper.h"

#include "../Math/mathUtil.h"

#include "resources.h"
#include "objectTypes.h"
#include "componentTypes.h"

#include "level.h"

static bool movingCamera = false;
static Vector2 prevMousePos;
static int32_t scrollAmt;

static Vector2 camCenterPos = { -400.0f, -300.0f };

static uint32_t overX;
static uint32_t overY;

static int cellImg;

static bool mouseOverUI;

typedef enum {
	TAB_LEVEL,
	TAB_TILES,
	TAB_OBJECTS
} EditorTab;

static EditorTab currTab;

static uint32_t currLevel;

static struct nk_image* sbNKTileImages;

static int tileDefaultFlipped;
static int tileDefaultImg;

static int objectType;
static EntityID selectedObject;
static EntityID placingObject;

static bool leftMousePressed;
static bool rightMousePressed;
static bool ignoreKeyPresses;

static Vector2 camMove;

static ECPSSetup editorSetup;

static Process renderProc;
static Process selectProc;
static Process genObjListProc;

static Vector2 worldMousePos;

static void render( const Entity* entity )
{
	PosData* pos = NULL;
	RenderData* rd = NULL;

	ecps_GetComponentFromEntity( entity, editorSetup.posComp, &pos );
	ecps_GetComponentFromEntity( entity, editorSetup.renderComp, &rd );

	Vector2 currPos = pos->currPos;
	Vector2 futurePos = pos->futurePos;

	AnimatedData* animData = NULL;
	if( ecps_GetComponentFromEntity( entity, editorSetup.animatedComp, &animData ) ) {
		Vector2 offset = animData->anim->sbFrames[animData->frameIdx].offset;
		offset.x *= sign( rd->scale.x );
		offset.y *= sign( rd->scale.y );
		vec2_Add( &currPos, &offset, &currPos );
		vec2_Add( &futurePos, &offset, &futurePos );
	}

	RenderOffset* offset = NULL;
	if( ecps_GetComponentFromEntity( entity, editorSetup.renderOffsetComp, &offset ) ) {
		currPos.y += offset->yOffset;
		futurePos.y += offset->yOffset;
	}

	img_Draw_sv_c( rd->img, 1, currPos, futurePos, rd->scale, rd->scale, rd->clr, rd->clr, rd->depth );

	pos->currPos = pos->futurePos;
}

static LevelObject* sbLevelObjects = NULL;
static void clearCurrentObjectList( void )
{
	mem_Release( sbLevels[currLevel].objectLayout );
	sbLevels[currLevel].objectLayout = NULL;
}

static void addToCurrentObjectList( const Entity* entity )
{
	LevelObject newObj;

	ObjectTypeIndex* typeIdx = NULL;
	PosData* posData = NULL;
	RenderOffset* renderOffset = NULL;

	Vector2 pos;
	ecps_GetComponentFromEntity( entity, editorSetup.posComp, &posData );
	ecps_GetComponentFromEntity( entity, editorSetup.objectTypeIdxComp, &typeIdx );
	pos = posData->currPos;
	if( ecps_GetComponentFromEntity( entity, editorSetup.renderOffsetComp, &renderOffset ) ) {
		//pos.y -= renderOffset->yOffset;
	}

	newObj.objectType = typeIdx->idx;

	Vector2 basePos;
	basePos.x = -BASE_SIZE.w * ( ( (float)sbLevels[currLevel].width / 2.0f ) - 0.5f );
	basePos.y = -BASE_SIZE.h * ( ( (float)sbLevels[currLevel].height / 2.0f ) - 0.5f );
	vec2_Subtract( &pos, &basePos, &pos );
	pos.x /= BASE_SIZE.w;
	pos.y /= BASE_SIZE.h;

	newObj.xCoord = (uint32_t)pos.x;
	newObj.yCoord = (uint32_t)pos.y;

	sb_Push( sbLevelObjects, newObj );
}

static void finalizeCurrentObjectList( void )
{
	size_t numObjs = sb_Count( sbLevelObjects );

	sbLevels[currLevel].numObjects = numObjs;

	sbLevels[currLevel].objectLayout = mem_Allocate( sizeof( sbLevels[currLevel].objectLayout[0] ) * numObjs );
	for( size_t i = 0; i < numObjs; ++i ) {
		sbLevels[currLevel].objectLayout[i] = sbLevelObjects[i];
	}

	sb_Release( sbLevelObjects );
	sbLevelObjects = NULL;
}

static uint32_t genericPosToIdx( uint32_t x, uint32_t y, uint32_t width, uint32_t height )
{
	if( x > width ) return UINT32_MAX;
	if( y > height ) return UINT32_MAX;

	return ( ( y * width ) + x );
}

static uint32_t posToIdx( uint32_t x, uint32_t y )
{
	return genericPosToIdx( x, y, sbLevels[currLevel].width, sbLevels[currLevel].height );
}

static uint32_t currOverIdx( void )
{
	return posToIdx( overX, overY );
}

static EntityID* sbClickedIDs = NULL;
static void clearClickedList( void )
{
	sb_Clear( sbClickedIDs );
}

const float selectRadiusSqrd = ( BASE * BASE ) / 2.0f;
static void checkAndAddToClickedList( const Entity* entity )
{
	PosData* pd = NULL;

	ecps_GetComponentFromEntity( entity, editorSetup.posComp, &pd );

	if( vec2_DistSqrd( &(pd->currPos), &worldMousePos ) <= selectRadiusSqrd ) {
		sb_Push( sbClickedIDs, entity->id );
	}
}

static void chooseClickedEntity( void )
{
	if( sb_Count( sbClickedIDs ) == 0 ) {
		selectedObject = INVALID_ENTITY;
		return;
	}

	for( size_t i = 0; i < sb_Count( sbClickedIDs ) - 1; ++i ) {
		if( sbClickedIDs[i] == selectedObject ) {
			selectedObject = sbClickedIDs[i+1];
			return;
		}
	}

	// didn't find selected or is in last spot, then choose first
	selectedObject = sbClickedIDs[0];
}

static void onMiddlePressed( void )
{
	movingCamera = true;
	input_GetMousePosition( &prevMousePos );
}

static void onMiddleReleased( void )
{
	movingCamera = false;
}

static void onLeftPressed( void )
{
	leftMousePressed = true;

	if( currTab == TAB_OBJECTS ) {
		if( mouseOverUI ) return;

		if( placingObject != INVALID_ENTITY ) {
			// if we're placing an object set it's position
			if( ( overX != UINT32_MAX ) && ( overY != UINT32_MAX ) && !mouseOverUI ) {
				selectedObject = placingObject;
				placingObject = INVALID_ENTITY;
			}
		} else {
			// if we're creating or modifying an object run the object selection process
			ecps_RunProcess( &(editorSetup.ecps), &selectProc );
		}
		
	}
}

static void onLeftReleased( void )
{
	leftMousePressed = false;
}

static void onRightPressed( void )
{
	rightMousePressed = true;

	if( currTab == TAB_OBJECTS ) {
		if( placingObject != INVALID_ENTITY ) {
			// if we're placing an object destroy it
			ecps_DestroyEntityByID( &(editorSetup.ecps), placingObject );
			placingObject = INVALID_ENTITY;
		} else {
			// if we're modifying an object then deselect the current selection
			selectedObject = INVALID_ENTITY;
		}
	}
}

static void onRightReleased( void )
{
	rightMousePressed = false;
}

static void onePressed( void )
{
	if( ignoreKeyPresses ) return;
	currTab = TAB_LEVEL;
}

static void twoPressed( void )
{
	if( ignoreKeyPresses ) return;
	currTab = TAB_TILES;
}

static void threePressed( void )
{
	if( ignoreKeyPresses ) return;
	if( currTab != TAB_OBJECTS ) {
		placingObject = INVALID_ENTITY;
		selectedObject = INVALID_ENTITY;
	}
	currTab = TAB_OBJECTS;
}

#define CAM_KEY_MOVE_SPEED 256.0f
static void camMoveUp( void )
{
	if( ignoreKeyPresses ) return;
	camMove.y -= CAM_KEY_MOVE_SPEED;
}

static void camMoveDown( void )
{
	if( ignoreKeyPresses ) return;
	camMove.y += CAM_KEY_MOVE_SPEED;
}

static void camMoveLeft( void )
{
	if( ignoreKeyPresses ) return;
	camMove.x -= CAM_KEY_MOVE_SPEED;
}

static void camMoveRight( void )
{
	if( ignoreKeyPresses ) return;
	camMove.x += CAM_KEY_MOVE_SPEED;
}

static void createNewLevel( void )
{
	LevelDefinition newLevel;

	newLevel.width = 40;
	newLevel.height = 10;
	newLevel.numObjects = 0;
	newLevel.objectLayout = NULL;

	newLevel.tileLayout = mem_Allocate( sizeof( newLevel.tileLayout[0] ) * newLevel.width * newLevel.height );
	memset( newLevel.tileLayout, 0, sizeof( newLevel.tileLayout[0] ) * newLevel.width * newLevel.height );

	strcpy( newLevel.name, "New Level" );

	sb_Push( sbLevels, newLevel );
}

static void setCurrentLevel( uint32_t idx )
{
	currLevel = idx;

	Vector2 basePos;
	basePos.x = -BASE_SIZE.w * ( ( (float)sbLevels[currLevel].width / 2.0f ) - 0.5f );
	basePos.y = -BASE_SIZE.h * ( ( (float)sbLevels[currLevel].height / 2.0f ) - 0.5f );

	ecps_DestroyAllEntities( &(editorSetup.ecps) );

	for( uint32_t i = 0; i < sbLevels[currLevel].numObjects; ++i ) {
		LevelObject obj = sbLevels[currLevel].objectLayout[i];
		Vector2 pos = basePos;
		pos.x += BASE_SIZE.x * (float)obj.xCoord;
		pos.y += BASE_SIZE.y * (float)obj.yCoord;
		objectTypes[obj.objectType].create( &editorSetup, pos );
	}
}

static void destroyLevel( uint32_t idx )
{
	if( sb_Count( sbLevels ) <= 1 ) {
		llog( LOG_CRITICAL, "You must create a new level before you destroy this one." );
		return;
	}

	ecps_DestroyAllEntities( &(editorSetup.ecps) );

	if( currLevel >= idx ) {
		if( currLevel > 0 ) {
			--currLevel;
		}
	}

	sb_Remove( sbLevels, idx );

	setCurrentLevel( currLevel );
}

static void swapLevels( uint32_t idxOne, uint32_t idxTwo )
{
	if( idxOne >= sb_Count( sbLevels ) ) return;
	if( idxTwo >= sb_Count( sbLevels ) ) return;
	if( idxOne == idxTwo ) return;

	LevelDefinition temp;

	temp = sbLevels[idxOne];
	sbLevels[idxOne] = sbLevels[idxTwo];
	sbLevels[idxTwo] = temp;

	setCurrentLevel( currLevel ); // reload in case anything changed
}

static int levelEditorScreen_Enter( void )
{
	cam_TurnOnFlags( 0, 1 );
	// position the camera so the center of the screen is at (0,0)
	cam_SetState( 0, camCenterPos, 1.0f );
	
	gfx_SetClearColor( CLR_BLACK );

	movingCamera = false;
	scrollAmt = 0;
	currTab = TAB_LEVEL;

	input_BindOnMouseButtonPress( SDL_BUTTON_MIDDLE, onMiddlePressed );
	input_BindOnMouseButtonRelease( SDL_BUTTON_MIDDLE, onMiddleReleased );
	input_BindOnMouseButtonPress( SDL_BUTTON_LEFT, onLeftPressed );
	input_BindOnMouseButtonRelease( SDL_BUTTON_LEFT, onLeftReleased );
	input_BindOnMouseButtonPress( SDL_BUTTON_RIGHT, onRightPressed );
	input_BindOnMouseButtonRelease( SDL_BUTTON_RIGHT, onRightReleased );

	input_BindOnKeyPress( SDLK_1, onePressed );
	input_BindOnKeyPress( SDLK_2, twoPressed );
	input_BindOnKeyPress( SDLK_3, threePressed );

	input_BindOnKeyPress( SDLK_w, camMoveUp );
	input_BindOnKeyRelease( SDLK_w, camMoveDown );

	input_BindOnKeyPress( SDLK_s, camMoveDown );
	input_BindOnKeyRelease( SDLK_s, camMoveUp );

	input_BindOnKeyPress( SDLK_a, camMoveLeft );
	input_BindOnKeyRelease( SDLK_a, camMoveRight );

	input_BindOnKeyPress( SDLK_d, camMoveRight );
	input_BindOnKeyRelease( SDLK_d, camMoveLeft );

	overX = UINT32_MAX;
	overY = UINT32_MAX;

	cellImg = img_Load( "Images/cell.png", ST_DEFAULT );

	tileDefaultFlipped = 0;
	tileDefaultImg = 0;

	leftMousePressed = false;
	rightMousePressed = false;
	ignoreKeyPresses = false;

	selectedObject = INVALID_ENTITY;
	placingObject = INVALID_ENTITY;
	objectType = 0;

	// create the list of texture ids for the tile combo box
	GLuint* sbTileTextureIDs;
	sbTileTextureIDs = getTileTextureIDs( );;

	// create the images
	sbNKTileImages = NULL;
	for( size_t i = 0; i < sb_Count( sbTileTextureIDs ); ++i ) {
		struct nk_image nkImg = nk_image_id( sbTileTextureIDs[i] );
		sb_Push( sbNKTileImages, nkImg );
	}

	sb_Release( sbTileTextureIDs );

	// setup the ecps for the objects, only concerned about the renderable and position
	//editorSetup.
	ecps_StartInitialization( &(editorSetup.ecps) ); {

		editorSetup.posComp = ecps_AddComponentType( &(editorSetup.ecps), "Position", sizeof( PosData ), NULL );
		editorSetup.physicsComp = INVALID_COMPONENT_ID;
		editorSetup.playerInputComp = INVALID_COMPONENT_ID;
		editorSetup.renderComp = ecps_AddComponentType( &(editorSetup.ecps), "Render", sizeof( RenderData ), NULL );
		editorSetup.dynamicCollisionComp = INVALID_COMPONENT_ID;
		editorSetup.staticCollisionComp = INVALID_COMPONENT_ID;
		editorSetup.triggerCollisionComp = INVALID_COMPONENT_ID;
		editorSetup.zombieAIComp = INVALID_COMPONENT_ID;
		editorSetup.attachableComp = INVALID_COMPONENT_ID;
		editorSetup.dragFlagComp = INVALID_COMPONENT_ID;
		editorSetup.pushableFlagComp = INVALID_COMPONENT_ID;
		editorSetup.canPushFlagComp = INVALID_COMPONENT_ID;
		editorSetup.crushableFlagComp = INVALID_COMPONENT_ID;
		editorSetup.canCrushFlagComp = INVALID_COMPONENT_ID;
		editorSetup.destroyFlagComp = INVALID_COMPONENT_ID;
		editorSetup.reloadOnDeathFlagComp = INVALID_COMPONENT_ID;
		editorSetup.canRideFlagComp = INVALID_COMPONENT_ID;
		editorSetup.canBeRiddenFlagComp = INVALID_COMPONENT_ID;
		editorSetup.canKillAnythingComp = INVALID_COMPONENT_ID;
		editorSetup.canKillPlayerComp = INVALID_COMPONENT_ID;
		editorSetup.endLevelFlagComp = INVALID_COMPONENT_ID;
		editorSetup.animatedComp = ecps_AddComponentType( &(editorSetup.ecps), "Animated", sizeof( AnimatedData ), NULL );
		editorSetup.renderOffsetComp = ecps_AddComponentType( &(editorSetup.ecps), "Render Offset", sizeof( RenderOffset ), NULL );
		editorSetup.objectTypeIdxComp = ecps_AddComponentType( &(editorSetup.ecps), "Object Type Idx", sizeof( ObjectTypeIndex ), NULL );
		editorSetup.staticCollisionOffsetComp = INVALID_COMPONENT_ID;
		editorSetup.doNotRenderInGameFlagComp = INVALID_COMPONENT_ID;

		ecps_CreateProcess( &(editorSetup.ecps), "Render", NULL, render, NULL, &renderProc, 2, editorSetup.posComp, editorSetup.renderComp );
		ecps_CreateProcess( &(editorSetup.ecps), "Select", clearClickedList, checkAndAddToClickedList, chooseClickedEntity, &selectProc, 1, editorSetup.posComp );
		ecps_CreateProcess( &(editorSetup.ecps), "GenObjList", clearCurrentObjectList, addToCurrentObjectList, finalizeCurrentObjectList, &genObjListProc, 2,
			editorSetup.posComp, editorSetup.objectTypeIdxComp );
	} ecps_FinishInitialization( &(editorSetup.ecps) );

	if( sb_Count( sbLevels ) == 0 ) {
		createNewLevel( );
	}
	setCurrentLevel( 0 );

	return 0;
}

static int levelEditorScreen_Exit( void )
{
	input_ClearAllKeyBinds( );
	input_ClearAllMouseButtonBinds( );

	img_Clean( cellImg );

	sb_Release( sbNKTileImages );

	return 0;
}

static void levelEditorScreen_ProcessEvents( SDL_Event* e )
{
	if( e->type == SDL_MOUSEWHEEL ) {
		if( !mouseOverUI ) {
			scrollAmt += e->wheel.y;
		}
	}
}

static void levelEditorScreen_Process( void )
{
}

static void levelEditorScreen_Draw( void )
{
	ignoreKeyPresses = false;
	struct nk_rect uiBounds = { 0, 0, 200, 600 };
	mouseOverUI = false;

	Vector2 screenMousePos;
	input_GetMousePosition( &screenMousePos );
	Matrix4 inverseViewMtx;
	cam_GetInverseViewMatrix( 0, &inverseViewMtx );
	mat4_TransformVec2Pos( &inverseViewMtx, &screenMousePos, &worldMousePos );

	if( ( ( screenMousePos.x - uiBounds.x ) <= uiBounds.w ) &&
		( ( screenMousePos.y - uiBounds.y ) <= uiBounds.h ) ) {
		mouseOverUI = true;
	}
	
	// draw level grid and tiles
	Vector2 basePos;
	basePos.x = -BASE_SIZE.w * ( ( (float)sbLevels[currLevel].width / 2.0f ) - 0.5f );
	basePos.y = -BASE_SIZE.h * ( ( (float)sbLevels[currLevel].height / 2.0f ) - 0.5f );
	Vector2 halfSize;
	vec2_Scale( &BASE_SIZE, 0.5f, &halfSize );
	Vector2 imgSize;
	img_GetSize( cellImg, &imgSize );
	imgSize.w = BASE_SIZE.w / imgSize.w;
	imgSize.h = BASE_SIZE.h / imgSize.h;
	overX = UINT32_MAX;
	overY = UINT32_MAX;
	for( uint32_t y = 0; y < sbLevels[currLevel].height; ++y ) {
		for( uint32_t x = 0; x < sbLevels[currLevel].width; ++x ) {
			Vector2 pos = basePos;
			pos.x += BASE_SIZE.w * x;
			pos.y += BASE_SIZE.h * y;

			Color clr = CLR_BLUE;
			// detect which tile we're over here as well
			Vector2 diff;
			vec2_Subtract( &pos, &worldMousePos, &diff );
			if( ( fabsf( diff.x ) <= halfSize.w ) && ( fabsf( diff.y ) <= halfSize.h ) ) {
				clr = CLR_CYAN;
				overX = x;
				overY = y;
			}

			img_Draw_sv_c( cellImg, 1, pos, pos, imgSize, imgSize, clr, clr, 10 );

			uint32_t idx = posToIdx( x, y );
			if( idx == UINT32_MAX ) continue;
			if( sbLevels[currLevel].tileLayout[idx].inUse == 0 ) continue;

			Vector2 tileImgSize;
			TileImage tileImg = tileImages[sbLevels[currLevel].tileLayout[idx].img];
			img_GetSize( tileImg.img, &tileImgSize );
			tileImgSize.w = BASE_SIZE.w / tileImgSize.w * ( sbLevels[currLevel].tileLayout[idx].flipped ? -1.0f : 1.0f );
			tileImgSize.h = BASE_SIZE.h / tileImgSize.h;
			img_Draw_sv( tileImg.img, 1, pos, pos, tileImgSize, tileImgSize, 0 );
		}
	}

	// draw objects
	ecps_RunProcess( &(editorSetup.ecps), &renderProc );

	// ui
	struct nk_context* ctx = &(inGameIMGUI.ctx);
	nk_begin( ctx, "Editor", uiBounds, NK_WINDOW_BORDER | NK_WINDOW_TITLE ); {
		nk_menubar_begin( ctx ); {
			nk_layout_row_begin( ctx, NK_STATIC, 20, 4 );
            nk_layout_row_push( ctx, 50.0f );

			if( nk_menu_begin_label( ctx, "Tab", NK_TEXT_ALIGN_LEFT, nk_vec2( 75.0f, 150.0f ) ) ) {
				nk_layout_row_dynamic(ctx, 15, 1);
				if( nk_menu_item_label( ctx, "Level", NK_TEXT_ALIGN_LEFT ) ) {
					currTab = TAB_LEVEL;
				}
				if( nk_menu_item_label( ctx, "Tiles", NK_TEXT_ALIGN_LEFT ) ) {
					currTab = TAB_TILES;
				}
				if( nk_menu_item_label( ctx, "Objects", NK_TEXT_ALIGN_LEFT ) ) {
					if( currTab != TAB_OBJECTS ) {
						selectedObject = INVALID_ENTITY;
						placingObject = INVALID_ENTITY;
					}
					currTab = TAB_OBJECTS;
				}

				nk_menu_end( ctx );
			}
			if( nk_menu_begin_label( ctx, "Commands", NK_TEXT_ALIGN_LEFT, nk_vec2( 75.0f, 150.0f ) ) ) {
				nk_layout_row_dynamic(ctx, 15, 1);
				if( nk_menu_item_label( ctx, "Recenter", NK_TEXT_ALIGN_LEFT ) ) {
					cam_SetState( 0, camCenterPos, 1.0f );
				}

				if( nk_menu_item_label( ctx, "Save", NK_TEXT_ALIGN_LEFT ) ) {
					// generate the object list
					ecps_RunProcess( &(editorSetup.ecps), &genObjListProc );
					saveLevelsData( );
				}

				nk_menu_end( ctx );
			}

			switch( currTab ) {
			case TAB_LEVEL: {
					nk_layout_row_begin( ctx, NK_STATIC, 20, 1 );
					nk_layout_row_push( ctx, 160.0f );
					
					if( nk_combo_begin_label( ctx, sbLevels[currLevel].name, nk_vec2( 160.0f, 200.0f ) ) ) {
						nk_layout_row_dynamic( ctx, 25, 1 );
						for( size_t i = 0; i < sb_Count( sbLevels ); ++i ) {
							if( nk_combo_item_label( ctx, sbLevels[i].name, NK_TEXT_LEFT ) ) {
								setCurrentLevel( i );
							}
						}
						nk_combo_end(ctx);
					}

					nk_layout_row_begin( ctx, NK_STATIC, 5, 1 );
					nk_layout_row_begin( ctx, NK_STATIC, 20, 1 );
					nk_layout_row_push( ctx, 160.0f );
					nk_labelf( ctx, NK_TEXT_CENTERED, "LEVEL %i", currLevel );

					nk_layout_row_begin( ctx, NK_STATIC, 20, 1 );
					nk_layout_row_push( ctx, 160.0f );
					nk_flags editResult = nk_edit_string_zero_terminated( ctx,
						NK_EDIT_FIELD | NK_EDIT_SELECTABLE | NK_EDIT_GOTO_END_ON_ACTIVATE, sbLevels[currLevel].name, ARRAY_SIZE( sbLevels[currLevel].name ), NULL );
					ignoreKeyPresses = ( editResult & ( NK_EDIT_ACTIVE | NK_EDIT_ACTIVATED ) ) != 0;

					nk_layout_row_begin( ctx, NK_STATIC, 20, 1 );
					nk_layout_row_push( ctx, 160.0f );
					uint32_t newWidth = (uint32_t)nk_propertyi( ctx, "Width", 5, sbLevels[currLevel].width, 500, 1, 0.05f );
					nk_layout_row_begin( ctx, NK_STATIC, 20, 1 );
					nk_layout_row_push( ctx, 160.0f );
					uint32_t newHeight = (uint32_t)nk_propertyi( ctx, "Height", 5, sbLevels[currLevel].height, 500, 1, 0.05f );

					if( ( newWidth != sbLevels[currLevel].width ) || ( newHeight != sbLevels[currLevel].height ) ) {
						size_t newSize = sizeof( LevelTile ) * newWidth * newHeight;
						LevelTile* newTiles = mem_Allocate( newSize );
						memset( newTiles, 0, newSize );

						uint32_t minWidth = MIN( newWidth, sbLevels[currLevel].width );
						uint32_t minHeight = MIN( newHeight, sbLevels[currLevel].height );

						// copy over old data to new storage
						uint32_t origY = sbLevels[currLevel].height;
						for( uint32_t y = newHeight; ( y > 0 ) && ( origY > 0 ); --y, --origY ) {
							for( uint32_t x = 0; x < minWidth; ++x ) {
								uint32_t newIdx = genericPosToIdx( x, y - 1, newWidth, newHeight );
								uint32_t oldIdx = posToIdx( x, origY - 1 );
								newTiles[newIdx] = sbLevels[currLevel].tileLayout[oldIdx];
							}
						}

						sbLevels[currLevel].height = newHeight;
						sbLevels[currLevel].width = newWidth;

						mem_Release( sbLevels[currLevel].tileLayout );
						sbLevels[currLevel].tileLayout = newTiles;
					}

					nk_layout_row_begin( ctx, NK_STATIC, 20, 2 );
					nk_layout_row_push( ctx, 80.0f );
					if( currLevel == 0 ) {
						nk_spacing( ctx, 1 );
					} else {
						if( nk_button_label( ctx, "Move Up" ) ) {
							uint32_t newIdx = currLevel - 1;
							swapLevels( currLevel, newIdx );
							setCurrentLevel( newIdx );
						}
					}

					if( currLevel >= ( sb_Count( sbLevels ) - 1 ) ) {
						nk_spacing( ctx, 1 );
					} else {
						if( nk_button_label( ctx, "Move Down" ) ) {
							uint32_t newIdx = currLevel + 1;
							swapLevels( currLevel, newIdx );
							setCurrentLevel( newIdx );
						}
					}

					nk_layout_row_begin( ctx, NK_STATIC, 40, 1 );
					nk_layout_row_begin( ctx, NK_STATIC, 20, 1 );
					nk_layout_row_push( ctx, 160.0f );
					if( nk_button_label( ctx, "Add New" ) ) {
						createNewLevel( );
						setCurrentLevel( sb_Count( sbLevels ) - 1 );
					}

					nk_layout_row_begin( ctx, NK_STATIC, 40, 1 );
					nk_layout_row_begin( ctx, NK_STATIC, 20, 1 );
					nk_layout_row_push( ctx, 160.0f );
					if( nk_button_label( ctx, "Delete Current" ) ) {
						destroyLevel( currLevel );
					}
				} break;
			case TAB_TILES: {
					nk_layout_row_begin( ctx, NK_STATIC, 20, 1 );
					nk_layout_row_push( ctx, 160.0f );
					nk_label( ctx, "TILES", NK_TEXT_CENTERED );

					uint32_t overIdx = currOverIdx( );
					if( ( overIdx != UINT32_MAX ) && !mouseOverUI ) {
						if( leftMousePressed && !rightMousePressed ) {
							sbLevels[currLevel].tileLayout[overIdx].inUse = true;
							sbLevels[currLevel].tileLayout[overIdx].flipped = tileDefaultFlipped;
							sbLevels[currLevel].tileLayout[overIdx].img = tileDefaultImg;
						} else if( rightMousePressed && !leftMousePressed ) {
							if( sbLevels[currLevel].tileLayout[overIdx].inUse ) {
								sbLevels[currLevel].tileLayout[overIdx].inUse = false;
							}
						}
					}

					nk_layout_row_begin( ctx, NK_STATIC, 20, 1 );
					nk_layout_row_push( ctx, 160.0f );
					tileDefaultFlipped = nk_check_label( ctx, "Flipped", tileDefaultFlipped );

					for( size_t i = 0; i < sb_Count( sbNKTileImages ); ++i ) {
						if( i % 3 == 0 ) {
							nk_layout_row_begin( ctx, NK_STATIC, 48, 3 );
							nk_layout_row_push( ctx, 48.0f );
						}

						if( nk_button_image( ctx, sbNKTileImages[i] ) ) {
							tileDefaultImg = i;
						}
					}
				} break;
			case TAB_OBJECTS: {
					nk_layout_row_begin( ctx, NK_STATIC, 20, 1 );
					nk_layout_row_push( ctx, 160.0f );
					nk_label( ctx, "OBJECTS", NK_TEXT_CENTERED );

					nk_layout_row_begin( ctx, NK_STATIC, 5, 1 );

					if( placingObject != INVALID_ENTITY ) {
						// find the tile we're over and position the placingObject there
						PosData* pd = NULL;
						if( ecps_GetComponentFromEntityByID( &(editorSetup.ecps), placingObject, editorSetup.posComp, &pd ) ) {
							Vector2 pos = basePos;
							pos.x += BASE_SIZE.w * clamp( 0, ( (float)sbLevels[currLevel].width ) - 1.0f, (float)overX );
							pos.y += BASE_SIZE.h * clamp( 0, ( (float)sbLevels[currLevel].height ) - 1.0f, (float)overY );

							pd->currPos = pos;
							pd->futurePos = pos;
						}
					} else if( selectedObject != INVALID_ENTITY ) {
						PosData* posData;
						if( ecps_GetComponentFromEntityByID( &(editorSetup.ecps), selectedObject, editorSetup.posComp, &posData ) ) {
							img_Draw_sv_c( cellImg, 1, posData->currPos, posData->currPos, imgSize, imgSize, CLR_GREEN, CLR_GREEN, 11 );
						}

						nk_layout_row_begin( ctx, NK_STATIC, 20, 1 );
						nk_layout_row_push( ctx, 160.0f );
						if( nk_button_label( ctx, "Destroy" ) ) {
							ecps_DestroyEntityByID( &(editorSetup.ecps), selectedObject );
							selectedObject = INVALID_ENTITY;
						}

						nk_layout_row_begin( ctx, NK_STATIC, 20, 1 );
						nk_layout_row_push( ctx, 160.0f );
						if( nk_button_label( ctx, "Move" ) ) {
							placingObject = selectedObject;
							selectedObject = INVALID_ENTITY;
						}
					} else {
						nk_layout_row_begin( ctx, NK_STATIC, 20, 1 );
						nk_layout_row_push( ctx, 160.0f );
						// chosen object type
						if( nk_combo_begin_label( ctx, objectTypes[objectType].name, nk_vec2( 160.0f, 200.0f ) ) ) {
							nk_layout_row_dynamic( ctx, 25, 1 );
							for( size_t i = 0; i < numObjectTypes( ); ++i ) {
								if( nk_combo_item_label( ctx, objectTypes[i].name, NK_TEXT_LEFT ) ) {
									objectType = i;
								}
							}
							nk_combo_end(ctx);
						}

						nk_layout_row_begin( ctx, NK_STATIC, 20, 1 );
						nk_layout_row_push( ctx, 160.0f );
						if( nk_button_label( ctx, "Create" ) ) {
							Vector2 pos = VEC2_ZERO;
							placingObject = objectTypes[objectType].create( &editorSetup, pos );
						}
					}
				} break;
			}
		} nk_menubar_end( ctx );
	} nk_end( ctx );//*/

	//debugRenderer_Circle( 1, VEC2_ZERO, 10.0f, CLR_MAGENTA );
}

static void levelEditorScreen_PhysicsTick( float dt )
{
	Vector2 mousePosDelta = VEC2_ZERO;
	if( movingCamera ) {
		Vector2 mousePos;
		input_GetMousePosition( &mousePos );
		vec2_Subtract( &prevMousePos, &mousePos, &mousePosDelta );
		prevMousePos = mousePos;
	} else {
		vec2_Scale( &camMove, dt, &mousePosDelta );
	}

	cam_MoveNextState( 0, mousePosDelta, scrollAmt * 0.1f );
	scrollAmt = 0;
}

struct GameState levelEditorScreenState = { levelEditorScreen_Enter, levelEditorScreen_Exit, levelEditorScreen_ProcessEvents,
	levelEditorScreen_Process, levelEditorScreen_Draw, levelEditorScreen_PhysicsTick };