#include "resources.h"

#include "../Graphics/Images.h"
#include "../Graphics/ImageSheets.h"
#include "../UI/text.h"
#include "../sound.h"
#include "../Utils/helpers.h"

#include "objectTypes.h"
#include "level.h"

const Vector2 BASE_SIZE = { BASE, BASE };

int displayFont = -1;

int whiteSquare = -1;
int crateImg = -1;
int smokeImg = -1;
int bgImg = -1;
int arrowSignImg = -1;
int bush0Img = -1;
int bush1Img = -1;
int deadBushImg = -1;
int deco0Img = -1;
int deco1Img = -1;
int deco2Img = -1;
int deco3Img = -1;
int signImg = -1;
int skeletonImg = -1;
int tombStone0Img = -1;
int tombStone1Img = -1;
int treeImg = -1;

#define LOAD_AND_TEST( file, func, id ) \
	id = func( file ); if( id < 0 ) { \
		SDL_LogError( SDL_LOG_CATEGORY_APPLICATION, "Error loading resource file %s.", file ); }

#define LOAD_AND_TEST_IMG( file, shaderType, id ) \
	id = img_Load( file, shaderType ); if( id < 0 ) { \
		SDL_LogError( SDL_LOG_CATEGORY_APPLICATION, "Error loading resource file %s.", file ); }

#define LOAD_AND_TEST_FNT( file, size, id ) \
	id = txt_LoadFont( file, size ); if( id < 0 ) { \
		SDL_LogError( SDL_LOG_CATEGORY_APPLICATION, "Error loading resource file %s.", file ); }

#define LOAD_AND_TEST_SS( file, ids, cnt ) \
	{ ids = NULL; cnt = img_LoadSpriteSheet( file, ST_DEFAULT, &ids ); if( cnt < 0 ) { \
		SDL_LogError( SDL_LOG_CATEGORY_APPLICATION, "Error loading resource file %s.", file ); } }

#define LOAD_AND_TEST_MUSIC( file, id ) \
	id = snd_LoadStreaming( file, true, 0 ); if( id < 0 ) { \
		SDL_LogError( SDL_LOG_CATEGORY_APPLICATION, "Error loading resource file %s.", file ); }

#define LOAD_AND_TEST_SOUND( file, id ) \
	id = snd_LoadSample( file, 1, false ); if( id < 0 ) { \
		SDL_LogError( SDL_LOG_CATEGORY_APPLICATION, "Error loading resource file %s.", file ); }

//**************************************************************************************************

#define GIRL_FRAME_TIME ( 1.0f / 30.0f )

static AnimFrame girlIdleFrames[] = {
	{ "Images/girl/Idle (1).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Idle (2).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Idle (3).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Idle (4).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Idle (5).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Idle (6).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Idle (7).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Idle (8).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Idle (9).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Idle (10).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Idle (11).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Idle (12).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Idle (13).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Idle (14).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Idle (15).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Idle (16).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
};

Animation girlIdle = {
	true, NULL
};

static void loadGirlIdleAnim( void )
{
	loadAnimFrames( ARRAY_SIZE( girlIdleFrames ), girlIdleFrames, &girlIdle );
}

static AnimFrame girlWalkFrames[] = {
	{ "Images/girl/Walk (1).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Walk (2).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Walk (3).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Walk (4).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Walk (5).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Walk (6).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Walk (7).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Walk (8).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Walk (9).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Walk (10).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Walk (11).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Walk (12).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Walk (13).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Walk (14).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Walk (15).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Walk (16).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Walk (17).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Walk (18).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Walk (19).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Walk (20).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
};

Animation girlWalk = {
	true, NULL
};

static void loadGirlWalkAnim( void )
{
	loadAnimFrames( ARRAY_SIZE( girlWalkFrames ), girlWalkFrames, &girlWalk );
}

static AnimFrame girlRunFrames[] = {
	{ "Images/girl/Run (1).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Run (2).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Run (3).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Run (4).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Run (5).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Run (6).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Run (7).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Run (8).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Run (9).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Run (10).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Run (11).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Run (12).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Run (13).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Run (14).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Run (15).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Run (16).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Run (17).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Run (18).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Run (19).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
	{ "Images/girl/Run (20).png", -1, GIRL_FRAME_TIME, { -2.0f, -2.0f } },
};

Animation girlRun = {
	true, NULL
};

static void loadGirlRunAnim( void )
{
	loadAnimFrames( ARRAY_SIZE( girlRunFrames ), girlRunFrames, &girlRun );
}

static AnimFrame girlJumpUpFrames[] = {
	{ "Images/girl/Jump (11).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
};

Animation girlJumpUp = {
	true, NULL
};

static void loadGirlJumpUpAnim( void )
{
	loadAnimFrames( ARRAY_SIZE( girlJumpUpFrames ), girlJumpUpFrames, &girlJumpUp );
}

static AnimFrame girlJumpDownFrames[] = {
	{ "Images/girl/Jump (23).png", -1,  GIRL_FRAME_TIME, { -2.0f, -2.0f } },
};

Animation girlJumpDown = {
	true, NULL
};

static void loadGirlJumpDownAnim( void )
{
	loadAnimFrames( ARRAY_SIZE( girlJumpDownFrames ), girlJumpDownFrames, &girlJumpDown );
}

static void loadGirlAnimations( void )
{
	loadGirlIdleAnim( );
	loadGirlWalkAnim( );
	loadGirlRunAnim( );
	loadGirlJumpUpAnim( );
	loadGirlJumpDownAnim( );
}

//**************************************************************************************************

#define ZOMBIE_FRAME_TIME ( 1.0f / 30.0f )

static AnimFrame femaleZombieIdleFrames[] = {
	{ "Images/femaleZombie/Idle (1).png", -1,  ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Idle (2).png", -1,  ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Idle (3).png", -1,  ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Idle (4).png", -1,  ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Idle (5).png", -1,  ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Idle (6).png", -1,  ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Idle (7).png", -1,  ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Idle (8).png", -1,  ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Idle (9).png", -1,  ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Idle (10).png", -1, ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Idle (11).png", -1, ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Idle (12).png", -1, ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Idle (13).png", -1, ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Idle (14).png", -1, ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Idle (15).png", -1, ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
};

Animation femaleZombieIdle = {
	true, NULL
};

static void loadFemaleZombieIdleAnim( void )
{
	loadAnimFrames( ARRAY_SIZE( femaleZombieIdleFrames ), femaleZombieIdleFrames, &femaleZombieIdle );
}

static AnimFrame femaleZombieWalkFrames[] = {
	{ "Images/femaleZombie/Walk (1).png", -1,  ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Walk (2).png", -1,  ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Walk (3).png", -1,  ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Walk (4).png", -1,  ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Walk (5).png", -1,  ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Walk (6).png", -1,  ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Walk (7).png", -1,  ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Walk (8).png", -1,  ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Walk (9).png", -1,  ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
	{ "Images/femaleZombie/Walk (10).png", -1, ZOMBIE_FRAME_TIME, { -3.0f, -6.0f } },
};

Animation femaleZombieWalk = {
	true, NULL
};

static void loadFemaleZombieWalkAnim( void )
{
	loadAnimFrames( ARRAY_SIZE( femaleZombieWalkFrames ), femaleZombieWalkFrames, &femaleZombieWalk );
}

static AnimFrame maleZombieIdleFrames[] = {
	{ "Images/maleZombie/Idle (1).png", -1,  ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Idle (2).png", -1,  ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Idle (3).png", -1,  ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Idle (4).png", -1,  ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Idle (5).png", -1,  ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Idle (6).png", -1,  ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Idle (7).png", -1,  ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Idle (8).png", -1,  ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Idle (9).png", -1,  ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Idle (10).png", -1, ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Idle (11).png", -1, ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Idle (12).png", -1, ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Idle (13).png", -1, ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Idle (14).png", -1, ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Idle (15).png", -1, ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
};

static void loadFemaleZombieAnimations( void )
{
	loadFemaleZombieIdleAnim( );
	loadFemaleZombieWalkAnim( );
}

//**************************************************************************************************

Animation maleZombieIdle = {
	true, NULL
};

static void loadMaleZombieIdleAnim( void )
{
	loadAnimFrames( ARRAY_SIZE( maleZombieIdleFrames ), maleZombieIdleFrames, &maleZombieIdle );
}

static AnimFrame maleZombieWalkFrames[] = {
	{ "Images/maleZombie/Walk (1).png", -1,  ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Walk (2).png", -1,  ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Walk (3).png", -1,  ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Walk (4).png", -1,  ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Walk (5).png", -1,  ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Walk (6).png", -1,  ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Walk (7).png", -1,  ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Walk (8).png", -1,  ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Walk (9).png", -1,  ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
	{ "Images/maleZombie/Walk (10).png", -1, ZOMBIE_FRAME_TIME, { 3.0f, -6.0f } },
};

Animation maleZombieWalk = {
	true, NULL
};

static void loadMaleZombieWalkAnim( void )
{
	loadAnimFrames( ARRAY_SIZE( maleZombieWalkFrames ), maleZombieWalkFrames, &maleZombieWalk );
}

static void loadMaleZombieAnimations( void )
{
	loadMaleZombieIdleAnim( );
	loadMaleZombieWalkAnim( );
}

//**************** End animations

void loadResources( void )
{
	LOAD_AND_TEST_FNT( "Fonts/kenpixel.ttf", 128.0f, displayFont );

	LOAD_AND_TEST_IMG( "Images/white.png", ST_DEFAULT, whiteSquare );
	LOAD_AND_TEST_IMG( "Images/smoke.png", ST_DEFAULT, smokeImg );
	LOAD_AND_TEST_IMG( "Images/BG.png", ST_DEFAULT, bgImg );
	LOAD_AND_TEST_IMG( "Images/arrow_sign.png", ST_DEFAULT, arrowSignImg );
	LOAD_AND_TEST_IMG( "Images/bush0.png", ST_DEFAULT, bush0Img );
	LOAD_AND_TEST_IMG( "Images/bush1.png", ST_DEFAULT, bush1Img );
	LOAD_AND_TEST_IMG( "Images/deadBush.png", ST_DEFAULT, deadBushImg );
	LOAD_AND_TEST_IMG( "Images/deco0.png", ST_DEFAULT, deco0Img );
	LOAD_AND_TEST_IMG( "Images/deco1.png", ST_DEFAULT, deco1Img );
	LOAD_AND_TEST_IMG( "Images/deco2.png", ST_DEFAULT, deco2Img );
	LOAD_AND_TEST_IMG( "Images/deco3.png", ST_DEFAULT, deco3Img );
	LOAD_AND_TEST_IMG( "Images/sign.png", ST_DEFAULT, signImg );
	LOAD_AND_TEST_IMG( "Images/skeleton.png", ST_DEFAULT, skeletonImg );
	LOAD_AND_TEST_IMG( "Images/tombStone0.png", ST_DEFAULT, tombStone0Img );
	LOAD_AND_TEST_IMG( "Images/tombStone1.png", ST_DEFAULT, tombStone1Img );
	LOAD_AND_TEST_IMG( "Images/tree.png", ST_DEFAULT, treeImg );
	LOAD_AND_TEST_IMG( "Images/crate.png", ST_DEFAULT, crateImg );

	loadTileImages( );

	loadGirlAnimations( );
	loadFemaleZombieAnimations( );
	loadMaleZombieAnimations( );

	loadLevelsData( );
}