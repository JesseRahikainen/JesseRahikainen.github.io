#ifndef GAME_SCREEN_H
#define GAME_SCREEN_H

#include "../gameState.h"

struct GameState gameScreenState;

#endif // inclusion guard