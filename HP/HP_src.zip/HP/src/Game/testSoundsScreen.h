#ifndef TEST_SOUNDS_H
#define TEST_SOUNDS_H

#include "../gameState.h"

struct GameState testSoundsScreenState;

#endif // inclusion guard