#ifndef RESOURCES_H
#define RESOURCES_H

#include "../Math/vector2.h"
#include "animations.h"

// base tile size, all sizes should be based on these
#define BASE 64.0f
const extern Vector2 BASE_SIZE;

extern int displayFont;

extern int whiteSquare;
extern int crateImg;
extern int smokeImg;
extern int bgImg;
extern int arrowSignImg;
extern int bush0Img;
extern int bush1Img;
extern int deadBushImg;
extern int deco0Img;
extern int deco1Img;
extern int deco2Img;
extern int deco3Img;
extern int signImg;
extern int skeletonImg;
extern int tombStone0Img;
extern int tombStone1Img;
extern int treeImg;

extern Animation maleZombieWalk;
extern Animation maleZombieIdle;
extern Animation femaleZombieWalk;
extern Animation femaleZombieIdle;
extern Animation girlJumpDown;
extern Animation girlJumpUp;
extern Animation girlRun;
extern Animation girlWalk;
extern Animation girlIdle;

void loadResources( void );

#endif /* inclusion guard */