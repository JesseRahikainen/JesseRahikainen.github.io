#ifndef TEST_A_STAR_SCREEN_H
#define TEST_A_STAR_SCREEN_H

#include "../gameState.h"

struct GameState testAStarScreenState;

#endif // inclusion guard