#ifndef OBJECT_TYPES_H
#define OBJECT_TYPES_H

#include "../System/ECPS/entityComponentProcessSystem.h"
#include "../Math/vector2.h"
#include "componentTypes.h"
#include "../Graphics/glPlatform.h"

EntityID createPlayer( ECPSSetup* setup, Vector2 pos );
EntityID createStrongZombie( ECPSSetup* setup, Vector2 pos );
EntityID createFastZombie( ECPSSetup* setup, Vector2 pos );
EntityID createCrate( ECPSSetup* setup, Vector2 pos );
EntityID createKillTrigger( ECPSSetup* setup, Vector2 pos );
EntityID createEndLevelTrigger( ECPSSetup* setup, Vector2 pos );
EntityID createArrowSignSprite( ECPSSetup* setup, Vector2 pos );
EntityID createBush0Sprite( ECPSSetup* setup, Vector2 pos );
EntityID createBush1Sprite( ECPSSetup* setup, Vector2 pos );
EntityID createDeadBushSprite( ECPSSetup* setups, Vector2 pos );
EntityID createDeco0Sprite( ECPSSetup* setup, Vector2 pos );
EntityID createDeco1Sprite( ECPSSetup* setup, Vector2 pos );
EntityID createDeco2Sprite( ECPSSetup* setup, Vector2 pos );
EntityID createDeco3Sprite( ECPSSetup* setup, Vector2 pos );
EntityID createSignSprite( ECPSSetup* setup, Vector2 pos );
EntityID createSkeletonSprite( ECPSSetup* setup, Vector2 pos );
EntityID createTombstone0Sprite( ECPSSetup* setup, Vector2 pos );
EntityID createTombstone1Sprite( ECPSSetup* setup, Vector2 pos );
EntityID createTreeSprite( ECPSSetup* setup, Vector2 pos );

void createTile( ECPSSetup* setup, Vector2 pos, int img, float xScale, Vector2 collOffset, Vector2 collSize );

typedef struct {
	const char* name;
	EntityID (*create)( ECPSSetup*, Vector2 );
} ObjectType;

typedef struct {
	const char* fileName;
	int img;
	Vector2 collOffset;
	Vector2 collSize;
} TileImage;

extern ObjectType objectTypes[];
extern TileImage tileImages[];

void loadTileImages( void );
GLuint* getTileTextureIDs( void );
size_t numObjectTypes( void );

#endif /* inclusion guard */