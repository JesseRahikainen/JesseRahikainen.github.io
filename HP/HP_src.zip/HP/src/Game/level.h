#ifndef LEVEL_H
#define LEVEL_H

#include <stdbool.h>
#include <stdint.h>

typedef struct {
	uint32_t objectType;
	uint32_t xCoord;
	uint32_t yCoord;
} LevelObject;

typedef struct {
	uint32_t img;
	bool flipped;
	bool inUse;
} LevelTile;

/*
Level definition:
 There are two primary things: tiles and objects.
 Tiles will define the collision for the level, this can be a simple boolean
  that just tells you whether there is collision there or not, then depending on adjacent tiles we
  can choose what graphic to use
 Objects will have a position, facing and a template.
*/
typedef struct {
	char name[64];
	uint32_t width;
	uint32_t height;
	uint32_t numObjects;
	LevelTile* tileLayout;
	LevelObject* objectLayout;
} LevelDefinition;

extern LevelDefinition* sbLevels;

void loadLevelsData( void );
void saveLevelsData( void );

#endif /* inclusion guard */