#ifndef ANIMATIONS_H
#define ANIMATIONS_H

#include <stdbool.h>
#include <stddef.h>
#include "../Math/vector2.h"

typedef struct {
	const char* fileName;
	int img;
	float duration;
	Vector2 offset;
} AnimFrame;

typedef struct {
	bool loops;
	AnimFrame* sbFrames;
} Animation;

void loadAnimFrames( size_t numFrames, AnimFrame* frames, Animation* outAnim );

#endif /* inclusion guard */