#include "animations.h"

#include "resources.h"
#include "../Graphics/images.h"
#include "../Utils/stretchyBuffer.h"

void loadAnimFrames( size_t numFrames, AnimFrame* frames, Animation* outAnim )
{
	for( size_t i = 0 ; i < numFrames; ++i ) {
		AnimFrame newFrame = frames[i];
		newFrame.img = img_Load( newFrame.fileName, ST_DEFAULT );

		newFrame.offset.x *= ( BASE_SIZE.x / 32.0f );
		newFrame.offset.y *= ( BASE_SIZE.y / 32.0f );

		sb_Push( outAnim->sbFrames, newFrame );
	}
}