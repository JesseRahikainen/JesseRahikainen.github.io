#include "sweptCollisionDetection.h"

#include <stdint.h>
#include <float.h>
#include <stdbool.h>

#include "Utils\stretchyBuffer.h"
#include "Math\vector2.h"

typedef enum {
	SCT_DISABLED = -1,
	SCT_AABB,
	SCT_CIRCLE,
	NUM_SWEPT_COLLIDER_TYPES
} SweptCollisionType;

typedef struct {
	SweptCollisionType type;
	uint32_t collideWithFlags; // what we hit
	uint32_t flags; // what is able to hit us
	Vector2 startPos;
	Vector2 endPos;
} GeneralCollisionData;

typedef struct {
	GeneralCollisionData data;
	Vector2 dim;
} SweptAABB;

typedef struct {
	GeneralCollisionData data;
	float radius;
} SweptCircle;

typedef union {
	GeneralCollisionData data;
	SweptAABB aabb;
	SweptCircle circle;
} SweptCollider;

typedef struct {
	float t;
	size_t idxOne;
	size_t idxTwo;
} Collision;

// these all return the parameter between the startPos and endPos
static float SweptAABBvAABBTest( SweptCollider* aabbOne, SweptCollider* aabbTwo )
{
	return FLT_MAX;
}

static float SweptCirclevCircleTest( SweptCollider* circleOne, SweptCollider* circleTwo )
{
	return FLT_MAX;
}

static float SweptCirclevAABB( SweptCollider* circle, SweptCollider* aabb )
{
	return FLT_MAX;
}

static float SweptAABBvCircle( SweptCollider* aabb, SweptCollider* circle )
{
	return FLT_MAX;
}

typedef float(*CollisionCheck)( SweptCollider* collOne, SweptCollider* collTwo );
static CollisionCheck collisionChecks[NUM_SWEPT_COLLIDER_TYPES][NUM_SWEPT_COLLIDER_TYPES] = {
	{ SweptAABBvAABBTest, SweptAABBvCircle },
	{ SweptCirclevAABB, SweptCirclevCircleTest }
};

void sweptCollision_DetectAll( SweptCollider* sbColliders )
{
	bool foundCollision = true;

	while( foundCollision ) {
		foundCollision = false;
		Collision firstCollision = { FLT_MAX, SIZE_MAX, SIZE_MAX, };
		for( size_t i = 0; i < sb_Count( sbColliders ); ++i ) {
			if( sbColliders[i].data.type == SCT_DISABLED ) continue;

			for( size_t j = i + 1; j < sb_Count( sbColliders ); ++j ) {
				if( sbColliders[j].data.type == SCT_DISABLED ) continue;

				if( ( ( sbColliders[i].data.flags & sbColliders[j].data.collideWithFlags ) == 0 ) &&
					( ( sbColliders[i].data.collideWithFlags & sbColliders[j].data.flags ) == 0 ) ) {
					continue;
				}

				float t = collisionChecks[sbColliders[i].data.type][sbColliders[j].data.type]( &( sbColliders[i] ), &( sbColliders[j] ) );
				if( t < firstCollision.t ) {
					firstCollision.t = t;
					firstCollision.idxOne = i;
					firstCollision.idxTwo = j;
				}
			}
		}

//#error working here!
		if( ( firstCollision.t >= 0.0f ) && ( firstCollision.t <= 1.0f ) ) {
			// process collision

			// advance all collisions
			for( size_t i = 0; i < sb_Count( sbColliders ); ++i ) {
				vec2_Lerp( &( sbColliders[i].data.startPos ), &( sbColliders[i].data.endPos ), firstCollision.t, &( sbColliders[i].data.startPos ) );
			}

			// add pair to ignore list?
			// redo collision detection

			foundCollision = true;
		}
	}
}